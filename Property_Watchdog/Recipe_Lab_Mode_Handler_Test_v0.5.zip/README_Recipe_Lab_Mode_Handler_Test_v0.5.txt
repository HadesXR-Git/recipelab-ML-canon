Recipe Lab - Mode Handler Test v0.5
Target: Canon EOS 700D firmware 1.1.5, Magic Lantern Nightly.2018Jul03.700D115 (Crop Mood).

Purpose
- Attach one temporary Lua property handler to SHOOTING_MODE.
- Poll camera.mode independently.
- Use task.yield() during the capture so the Lua property-dispatch task can run.
- Save a report to ML/LOGS/RLMODE05.TXT.

IMPORTANT: How to launch
Magic Lantern loads Lua scripts from ML/SCRIPTS and each script registers its own menu entry. This version creates ONE direct action under ML > Scripts.

1. Copy the included ML folder to the SD-card root (merge with the existing ML folder).
2. Restart the camera or reload the Lua scripts using your usual Magic Lantern workflow.
3. Open the Magic Lantern menu, then open Scripts.
4. Highlight "Recipe Lab - Mode Handler Test v0.5".
5. PRESS SET once. Do not press MENU/Q expecting it to start.
6. The action launches the test task. The task then closes the ML menu itself, shows the console, and begins the capture countdown.
7. During the test, turn the mode dial P -> Av -> P several times, pausing briefly at Av.
8. Retrieve ML/LOGS/RLMODE05.TXT.

Why this is different from v0.4
- v0.4 registered a nested submenu: Scripts > Recipe Lab... > Start test. Merely exiting the ML menu only closed the menu and saved configuration; it did not invoke the nested action.
- v0.5 uses a single direct SET action under Scripts. The worker closes the menu only after the action has been invoked.

Test behaviour
- It attaches only one temporary handler to property.SHOOTING_MODE.
- It polls camera.mode independently.
- It does not change Picture Style values or exposure settings.
- It detaches the handler when the 60-second test ends.

Output
ML/LOGS/RLMODE05.TXT

Safety
- No firmware addresses are called.
- No Picture Style properties are written.
- Do not run another script that registers a SHOOTING_MODE handler at the same time.
