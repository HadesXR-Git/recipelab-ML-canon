Recipe Lab - Mode Handler Test v0.4

Target: Canon EOS 700D firmware 1.1.5, Magic Lantern Nightly.2018Jul03.700D115 (Crop Mood).

Purpose
- Attach one temporary Lua property handler to SHOOTING_MODE.
- Poll camera.mode independently.
- IMPORTANT: use task.yield() during the wait so the Lua property-dispatch task can acquire the shared Lua-state semaphore.

Why this revision
The previous v0.3 used msleep() in its long-running Lua task. In the Magic Lantern Lua implementation, property callbacks are delivered by a separate task that must acquire the same Lua-state semaphore. task.yield() releases that semaphore while waiting and reacquires it afterwards. Using msleep() can leave the semaphore held, preventing the callback task from running.

Install
1. Copy recipe_lab_property_watch_v0.4.lua to ML/SCRIPTS/.
2. Launch it from Magic Lantern > Scripts.
3. Select Start 60-second mode handler test.
   The script uses task.yield() before, during and after capture so the property dispatcher can run.
4. During the test, turn the mode dial P -> Av -> P several times.
5. Retrieve ML/LOGS/RLMODE04.TXT.

Safety
- One temporary SHOOTING_MODE handler only.
- No Picture Style properties are registered or changed.
- No camera setting setters or undocumented firmware calls are used.
- The handler is detached at the end of the test.

Do not run another Lua script that registers a SHOOTING_MODE handler at the same time.
