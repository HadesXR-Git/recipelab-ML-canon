RECIPE LAB - USER DEFINED 1 PARAMETER WATCH v0.5
Target: Canon EOS 700D / firmware 1.1.5
Magic Lantern: Nightly.2018Jul03.700D115 (Crop Mood)

PURPOSE
A focused 30-second, passive test of the PICTURE_STYLE and PC_FLAVOR1_PARAM
property callbacks. Based on the previously successful Property Watch v0.4
and Mode Handler Test v0.5.

INSTALLATION
1. Copy recipe_lab_property_watch_v0.5.lua to:
   ML/SCRIPTS/recipe_lab_property_watch_v0.5.lua
2. Safely eject the SD card and put it in the EOS 700D.
3. Boot Magic Lantern and open ML > Scripts.
4. Highlight "Recipe Lab - User Def. 1 Watch v0.5" and press SET.
   Pressing MENU/Q to leave the ML menu does not start the test.

TEST (30 SECONDS)
Before starting, know how to reach Canon's Picture Style > User Defined 1
> Detail set / parameter adjustment screen.

During the capture window:
1. Select User Defined 1 and confirm with SET.
2. Open its Detail set / parameter menu.
3. Note the current Contrast value so you can restore it exactly.
4. Increase Contrast by exactly ONE step and confirm with SET.
5. Restore the original Contrast value and confirm with SET.
6. Return to the shooting view.

Do not change any other Picture Style parameter. The script itself does not
write any camera settings; the one-step Contrast change is performed manually
and restored manually by the user. If the UI offers an explicit cancel option
before saving, do not use it for the test because we want to observe a confirmed
parameter update followed by its restoration.

The script has a 5-second countdown, then closes the ML menu and captures for
30 seconds. Keep the test within the capture window.

OUTPUT
The report is written and read-back verified at:
ML/LOGS/RLPCH05.TXT

WHAT IT WATCHES
- PICTURE_STYLE: known-working notification when the active style changes.
- PC_FLAVOR1_PARAM: notification associated with User Defined 1 parameters.

The callback records the value type and, for string payloads, the first 128
bytes in hexadecimal (plus the total payload length). It does not attempt to
interpret or modify the payload.

SAFETY
- Does not call property:request_change().
- Does not call dryos.call().
- Does not write Picture Style properties or camera settings.
- Does not replace an existing Lua function handler.
- Detaches every temporary handler it successfully attached.
- The only camera setting change is the user's manual one-step Contrast test,
  which must be restored to its original value before the test ends.

If the script is interrupted or the camera loses power before completion,
the report may not be written. Rebooting clears temporary Lua handlers.
