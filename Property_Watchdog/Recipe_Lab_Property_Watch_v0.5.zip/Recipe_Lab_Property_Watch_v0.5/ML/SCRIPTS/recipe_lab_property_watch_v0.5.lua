-- Recipe Lab - User Defined 1 parameter watch v0.5
-- Target: Canon EOS 700D / firmware 1.1.5 / ML Nightly.2018Jul03.700D115
--
-- Focused passive diagnostic based on the physically tested v0.4 watcher.
-- Watches PICTURE_STYLE and PC_FLAVOR1_PARAM only.
-- During capture, the user manually selects User Defined 1, changes Contrast
-- by exactly one step, confirms it, then restores the original value.
--
-- The script itself does NOT change any camera setting or call request_change(),
-- dryos.call(), or property setters. It only registers temporary handlers.
-- Output: ML/LOGS/RLPCH05.TXT

local LOG_DIR = "ML/LOGS"
local LOG_NAME = "RLPCH05.TXT" -- strict FAT 8.3
local CAPTURE_MS = 30000
local POLL_MS = 250
local MAX_EVENTS = 80

local total_events = 0
local stored_events = {}
local dropped_events = 0
local callback_errors = 0
local callback_error_text = nil
local attach_results = {}
local attached_targets = {}

local function safe_tostring(value)
    local ok, result = pcall(tostring, value)
    if ok then return result end
    return "<tostring-error>"
end

local function safe_type(value)
    local ok, result = pcall(type, value)
    if ok then return result end
    return "<type-error>"
end

local function add_line(lines, value)
    lines[#lines + 1] = safe_tostring(value)
end

local function clip_text(value, limit)
    local text = safe_tostring(value)
    text = string.gsub(text, "%z", "<NUL>")
    if #text > limit then
        text = string.sub(text, 1, limit) .. "..."
    end
    return text
end

local function describe_value(value)
    if type(value) == "string" then
        local bytes = {}
        local count = math.min(#value, 128)
        for i = 1, count do
            bytes[#bytes + 1] = string.format("%02X", string.byte(value, i))
        end
        local suffix = (#value > count) and " ...[truncated]" or ""
        return "string[" .. tostring(#value) .. "] hex=" .. table.concat(bytes, " ") .. suffix
    end
    return clip_text(value, 180)
end

local function make_handler(target)
    -- Confirmed on this build by RLMODE05 and RLPCH04:
    -- property callback signature is function(self, value).
    return function(self_arg, value_arg)
        total_events = total_events + 1
        target.events = target.events + 1

        local ok, err = pcall(function()
            if #stored_events < MAX_EVENTS then
                stored_events[#stored_events + 1] = {
                    index = total_events,
                    target = target.name,
                    self_type = safe_type(self_arg),
                    self_value = clip_text(self_arg, 70),
                    value_type = safe_type(value_arg),
                    value = describe_value(value_arg)
                }
            else
                dropped_events = dropped_events + 1
            end
        end)

        if not ok then
            callback_errors = callback_errors + 1
            callback_error_text = clip_text(err, 180)
        end
    end
end

local function detach_handlers()
    for i = #attached_targets, 1, -1 do
        local target = attached_targets[i]
        local ok, err = pcall(function()
            target.object.handler = nil
        end)
        target.detach_ok = ok
        if ok then
            target.detach_error = nil
        else
            target.detach_error = safe_tostring(err)
        end
        attach_results[#attach_results + 1] = target.name .. " | detach=" .. safe_tostring(ok)
        if not ok then
            attach_results[#attach_results + 1] = target.name .. " | detach_error=" .. safe_tostring(err)
        end
    end
end

local function attach_handlers(targets)
    for _, target in ipairs(targets) do
        local object = target.object
        if object == nil then
            target.attach_status = "OBJECT_NIL"
            attach_results[#attach_results + 1] = target.name .. " | object=nil | SKIPPED"
        else
            local before_ok, before_value = pcall(function() return object.handler end)
            target.before_type = before_ok and safe_type(before_value) or "read-error"
            target.before_value = before_ok and clip_text(before_value, 80) or clip_text(before_value, 80)

            -- Do not replace another script's active Lua handler.
            if before_ok and safe_type(before_value) == "function" then
                target.attach_status = "EXISTING_FUNCTION_NOT_REPLACED"
                attach_results[#attach_results + 1] = target.name .. " | existing Lua handler | NOT REPLACED"
            else
                target.callback = make_handler(target)
                local assign_ok, assign_error = pcall(function()
                    object.handler = target.callback
                end)
                target.assign_ok = assign_ok
                target.assign_error = assign_ok and "none" or safe_tostring(assign_error)

                local readback_ok, readback_value = pcall(function() return object.handler end)
                target.readback_ok = readback_ok
                target.readback_type = readback_ok and safe_type(readback_value) or "read-error"
                target.readback_same = readback_ok and readback_value == target.callback or false

                if assign_ok and readback_ok and target.readback_same then
                    target.attach_status = "ATTACHED_VERIFIED"
                    attached_targets[#attached_targets + 1] = target
                else
                    target.attach_status = "ATTACH_NOT_VERIFIED"
                    if readback_ok and readback_value == target.callback then
                        pcall(function() object.handler = nil end)
                    end
                end

                attach_results[#attach_results + 1] = string.format(
                    "%s | before=%s:%s | assign=%s | readback=%s | same=%s | %s",
                    target.name,
                    safe_tostring(target.before_type),
                    safe_tostring(target.before_value),
                    safe_tostring(target.assign_ok),
                    safe_tostring(target.readback_type),
                    safe_tostring(target.readback_same),
                    safe_tostring(target.attach_status)
                )
            end
        end
    end
end

local function build_report(targets)
    local lines = {}
    add_line(lines, "RECIPE LAB - USER DEFINED 1 PARAMETER WATCH v0.5")
    add_line(lines, "Target: Canon EOS 700D / firmware 1.1.5")
    add_line(lines, "Build: ML Nightly.2018Jul03.700D115 (Crop Mood)")
    add_line(lines, "Mode: PASSIVE callbacks only; no camera settings written by script")
    add_line(lines, "Capture duration: " .. tostring(CAPTURE_MS) .. " ms")
    add_line(lines, "User action: select User Defined 1; Contrast +1; confirm; restore original; confirm")
    add_line(lines, "")

    add_line(lines, "[TARGET ATTACHMENT RESULTS]")
    for _, target in ipairs(targets) do
        add_line(lines, target.name .. " | object=" .. safe_tostring(target.object ~= nil))
        add_line(lines, "  before=" .. safe_tostring(target.before_type) .. ":" .. safe_tostring(target.before_value))
        add_line(lines, "  assign=" .. safe_tostring(target.assign_ok) .. " | readback=" .. safe_tostring(target.readback_type) .. " | same=" .. safe_tostring(target.readback_same))
        add_line(lines, "  status=" .. safe_tostring(target.attach_status) .. " | callbacks=" .. tostring(target.events))
    end
    add_line(lines, "")

    add_line(lines, "[HANDLER ATTACH / DETACH LOG]")
    for _, line in ipairs(attach_results) do add_line(lines, line) end
    add_line(lines, "")

    add_line(lines, "[EVENT SUMMARY]")
    add_line(lines, "Total callback invocations=" .. tostring(total_events))
    add_line(lines, "Events stored=" .. tostring(#stored_events))
    add_line(lines, "Events dropped=" .. tostring(dropped_events))
    add_line(lines, "Callback internal errors=" .. tostring(callback_errors))
    if callback_error_text ~= nil then
        add_line(lines, "Last callback error=" .. safe_tostring(callback_error_text))
    end
    add_line(lines, "")

    add_line(lines, "[RAW CALLBACK EVENTS]")
    if #stored_events == 0 then
        add_line(lines, "No callbacks received during capture window.")
    else
        for _, event in ipairs(stored_events) do
            add_line(lines, string.format(
                "%03d | %s | self=%s:%s | value=%s:%s",
                event.index,
                event.target,
                event.self_type,
                event.self_value,
                event.value_type,
                event.value
            ))
        end
    end
    add_line(lines, "")
    add_line(lines, "RECIPE_LAB_USER_DEFINED_1_WATCH_V05_END")
    return table.concat(lines, "\r\n") .. "\r\n"
end

local function save_report(report)
    local dir_ok, dir = pcall(function() return dryos.directory(LOG_DIR) end)
    if not dir_ok or dir == nil or dir.exists ~= true or dir.path == nil then
        return false, "LOG_DIR_UNAVAILABLE: " .. safe_tostring(dir)
    end

    local dir_path = safe_tostring(dir.path):gsub("\\", "/"):gsub("/+$", "")
    local path = dir_path .. "/" .. LOG_NAME
    local open_ok, file_or_error, open_error = pcall(io.open, path, "w")
    if not open_ok then return false, "LOG_OPEN_LUA_ERROR: " .. safe_tostring(file_or_error) end
    if file_or_error == nil then return false, "LOG_OPEN_FAILED: " .. safe_tostring(open_error) end

    local file = file_or_error
    local write_ok, write_result, write_error = pcall(function() return file:write(report) end)
    if not write_ok or write_result == nil then
        pcall(function() file:close() end)
        return false, "LOG_WRITE_FAILED: " .. safe_tostring(write_ok and write_error or write_result)
    end

    local flush_ok, flush_result, flush_error = pcall(function() return file:flush() end)
    if not flush_ok or flush_result == nil then
        pcall(function() file:close() end)
        return false, "LOG_FLUSH_FAILED: " .. safe_tostring(flush_ok and flush_error or flush_result)
    end

    local close_ok, close_result, close_error = pcall(function() return file:close() end)
    if not close_ok or close_result == nil then
        return false, "LOG_CLOSE_FAILED: " .. safe_tostring(close_ok and close_error or close_result)
    end

    local read_ok, read_file_or_error, read_error = pcall(io.open, path, "rb")
    if not read_ok or read_file_or_error == nil then
        return false, "LOG_READ_OPEN_FAILED: " .. safe_tostring(read_ok and read_error or read_file_or_error)
    end
    local read_file = read_file_or_error
    local contents_ok, contents = pcall(function() return read_file:read("*all") end)
    pcall(function() read_file:close() end)
    if not contents_ok or type(contents) ~= "string" then
        return false, "LOG_READ_FAILED: " .. safe_tostring(contents)
    end
    if contents ~= report then
        return false, "LOG_READBACK_MISMATCH: " .. tostring(#contents) .. " bytes"
    end

    return true, path .. " | " .. tostring(#contents) .. " bytes | readback verified"
end

local function run_watch()
    pcall(function() menu.close() end)

    total_events = 0
    stored_events = {}
    dropped_events = 0
    callback_errors = 0
    callback_error_text = nil
    attach_results = {}
    attached_targets = {}

    local targets = {
        { name = "PICTURE_STYLE", object = property.PICTURE_STYLE, events = 0 },
        { name = "PC_FLAVOR1_PARAM [User Defined 1]", object = property.PC_FLAVOR1_PARAM, events = 0 }
    }

    console.clear()
    console.show()
    print("RECIPE LAB - USER DEFINED 1 WATCH v0.5")
    print("Two temporary property handlers will be tested.")
    print("The script will not change any camera settings.")
    print("")
    print("Registering handlers...")
    attach_handlers(targets)

    print("Verified handlers: " .. tostring(#attached_targets) .. "/2")
    for _, target in ipairs(targets) do
        print(target.name .. ": " .. safe_tostring(target.attach_status))
    end

    if #attached_targets == 0 then
        print("")
        print("No handlers were attached. Capture aborted.")
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end

    console.clear()
    print("USER DEFINED 1 WATCH ACTIVE")
    print("")
    print("For the next 30 seconds:")
    print("1. Select User Defined 1 and confirm with SET.")
    print("2. Open its Detail set / parameter menu.")
    print("3. Note the current Contrast value.")
    print("4. Increase Contrast by exactly ONE step; confirm.")
    print("5. Restore the original Contrast value; confirm.")
    print("6. Return to shooting view.")
    print("")
    print("Do not adjust any other parameter.")
    print("Capture starts in 5 seconds; the menu will close.")
    task.yield(5000)
    console.hide()

    local elapsed = 0
    while elapsed < CAPTURE_MS do
        task.yield(POLL_MS)
        elapsed = elapsed + POLL_MS
    end

    detach_handlers()
    task.yield(500)

    local report = build_report(targets)
    local save_ok, save_result = save_report(report)

    console.show()
    console.clear()
    print("USER DEFINED 1 WATCH COMPLETE")
    print("Total callbacks: " .. tostring(total_events))
    for _, target in ipairs(targets) do
        print(target.name .. ": " .. tostring(target.events))
    end
    print("Callback errors: " .. tostring(callback_errors))
    print("")
    if save_ok then
        print("REPORT SAVE: VERIFIED")
        print("Retrieve: ML/LOGS/" .. LOG_NAME)
    else
        print("REPORT SAVE: FAILED")
        print(safe_tostring(save_result))
    end
    print("")
    print("Temporary handlers detached.")
    print("Press any key to return.")
    key.wait()
    console.hide()
end

local test_menu = menu.new {
    parent = "Scripts",
    name = "Recipe Lab - User Def. 1 Watch v0.5",
    help = "PRESS SET to monitor Picture Style and User Defined 1 parameter notifications for 30 seconds.",
    select = function(this)
        task.create(run_watch)
    end
}

print("Recipe Lab - User Defined 1 Watch v0.5 loaded. Press SET on its Scripts entry to run.")
