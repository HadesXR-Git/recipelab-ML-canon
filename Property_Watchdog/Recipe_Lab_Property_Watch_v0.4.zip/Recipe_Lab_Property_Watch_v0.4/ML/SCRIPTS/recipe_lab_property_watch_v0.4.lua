-- Recipe Lab - Picture Style Property Watch v0.4
-- Target: Canon EOS 700D / firmware 1.1.5 / ML Nightly.2018Jul03.700D115
--
-- v0.3 is based on the working SHOOTING_MODE handler test v0.5.
-- It uses task.yield() during capture so the Lua property dispatcher can run.
-- It registers temporary handlers for SHOOTING_MODE plus the four Picture
-- Style properties, records callback arguments, and detaches the handlers.
--
-- This is PASSIVE: it does not call request_change(), dryos.call(), or write
-- any camera/property settings. The user changes the mode dial and selects
-- Picture Styles manually during the capture window.
--
-- Output: ML/LOGS/RLPCH04.TXT

local LOG_DIR = "ML/LOGS"
local LOG_NAME = "RLPCH04.TXT" -- strict FAT 8.3
local CAPTURE_MS = 30000
local POLL_MS = 250
local MAX_EVENTS = 180
local MAX_MODE_CHANGES = 40

local total_events = 0
local stored_events = {}
local dropped_events = 0
local mode_changes = {}
local callback_errors = 0
local callback_error_text = nil
local attach_results = {}
local attached_targets = {}

local function safe_tostring(value)
    local ok, result = pcall(tostring, value)
    if ok then return result end
    return "<tostring-error>"
end

local function safe_type(value)
    local ok, result = pcall(type, value)
    if ok then return result end
    return "<type-error>"
end

local function add_line(lines, value)
    lines[#lines + 1] = safe_tostring(value)
end

local function clip_text(value, limit)
    local text = safe_tostring(value)
    -- Keep logs printable even if an API value contains embedded NUL bytes.
    text = string.gsub(text, "%z", "<NUL>")
    if #text > limit then
        text = string.sub(text, 1, limit) .. "..."
    end
    return text
end

local function describe_value(value)
    if type(value) == "string" then
        local bytes = {}
        local count = math.min(#value, 48)
        for i = 1, count do
            bytes[#bytes + 1] = string.format("%02X", string.byte(value, i))
        end
        local suffix = (#value > count) and "..." or ""
        return "string[" .. tostring(#value) .. "] hex=" .. table.concat(bytes, " ") .. suffix
    end
    return clip_text(value, 100)
end

local function make_handler(target)
    -- Confirmed by copy2m.lua and the successful RLMODE05 test:
    -- property handler signature is function(self, value).
    return function(self_arg, value_arg)
        -- Count immediately, before formatting or other work.
        total_events = total_events + 1
        target.events = target.events + 1

        local ok, err = pcall(function()
            if #stored_events < MAX_EVENTS then
                stored_events[#stored_events + 1] = {
                    index = total_events,
                    target = target.name,
                    self_type = safe_type(self_arg),
                    self_value = clip_text(self_arg, 70),
                    value_type = safe_type(value_arg),
                    value = describe_value(value_arg)
                }
            else
                dropped_events = dropped_events + 1
            end
        end)

        if not ok then
            callback_errors = callback_errors + 1
            callback_error_text = clip_text(err, 160)
        end
    end
end

local function detach_handlers()
    for i = #attached_targets, 1, -1 do
        local target = attached_targets[i]
        local ok, err = pcall(function()
            target.object.handler = nil
        end)
        target.detach_ok = ok
        if ok then
            target.detach_error = nil
        else
            target.detach_error = safe_tostring(err)
        end
        attach_results[#attach_results + 1] = target.name .. " | detach=" .. safe_tostring(ok)
        if not ok then
            attach_results[#attach_results + 1] = target.name .. " | detach_error=" .. safe_tostring(err)
        end
    end
end

local function attach_handlers(targets)
    for _, target in ipairs(targets) do
        local object = target.object
        if object == nil then
            target.attach_status = "OBJECT_NIL"
            attach_results[#attach_results + 1] = target.name .. " | object=nil | SKIPPED"
        else
            local before_ok, before_value = pcall(function()
                return object.handler
            end)
            target.before_type = before_ok and safe_type(before_value) or "read-error"
            target.before_value = before_ok and clip_text(before_value, 80) or clip_text(before_value, 80)

            -- Never replace another script's active Lua handler.
            if before_ok and safe_type(before_value) == "function" then
                target.attach_status = "EXISTING_FUNCTION_NOT_REPLACED"
                attach_results[#attach_results + 1] = target.name .. " | existing Lua handler | NOT REPLACED"
            else
                target.callback = make_handler(target)
                local assign_ok, assign_error = pcall(function()
                    object.handler = target.callback
                end)
                target.assign_ok = assign_ok
                target.assign_error = assign_ok and "none" or safe_tostring(assign_error)

                local readback_ok, readback_value = pcall(function()
                    return object.handler
                end)
                target.readback_ok = readback_ok
                target.readback_type = readback_ok and safe_type(readback_value) or "read-error"
                target.readback_same = readback_ok and readback_value == target.callback or false

                if assign_ok and readback_ok and target.readback_same then
                    target.attach_status = "ATTACHED_VERIFIED"
                    attached_targets[#attached_targets + 1] = target
                else
                    target.attach_status = "ATTACH_NOT_VERIFIED"
                    -- Best-effort cleanup only if this exact callback was read back.
                    if readback_ok and readback_value == target.callback then
                        pcall(function() object.handler = nil end)
                    end
                end

                attach_results[#attach_results + 1] = string.format(
                    "%s | before=%s:%s | assign=%s | readback=%s | same=%s | %s",
                    target.name,
                    safe_tostring(target.before_type),
                    safe_tostring(target.before_value),
                    safe_tostring(target.assign_ok),
                    safe_tostring(target.readback_type),
                    safe_tostring(target.readback_same),
                    safe_tostring(target.attach_status)
                )
            end
        end
    end
end

local function build_report(targets, info)
    local lines = {}
    add_line(lines, "RECIPE LAB - PICTURE STYLE PROPERTY WATCH v0.4")
    add_line(lines, "Target: Canon EOS 700D / firmware 1.1.5")
    add_line(lines, "Build: ML Nightly.2018Jul03.700D115 (Crop Mood)")
    add_line(lines, "Mode: PASSIVE callbacks + camera.mode polling")
    add_line(lines, "No request_change(), dryos.call(), or property setters used.")
    add_line(lines, "Capture duration: " .. tostring(CAPTURE_MS) .. " ms")
    add_line(lines, "")

    add_line(lines, "[TARGET ATTACHMENT RESULTS]")
    for _, target in ipairs(targets) do
        add_line(lines, target.name .. " | object=" .. safe_tostring(target.object ~= nil))
        add_line(lines, "  before=" .. safe_tostring(target.before_type) .. ":" .. safe_tostring(target.before_value))
        add_line(lines, "  assign=" .. safe_tostring(target.assign_ok) .. " | readback=" .. safe_tostring(target.readback_type) .. " | same=" .. safe_tostring(target.readback_same))
        add_line(lines, "  status=" .. safe_tostring(target.attach_status) .. " | callbacks=" .. tostring(target.events))
    end
    add_line(lines, "")

    add_line(lines, "[HANDLER ATTACH / DETACH LOG]")
    for _, line in ipairs(attach_results) do add_line(lines, line) end
    add_line(lines, "")

    add_line(lines, "[CAMERA.MODE CONTROL POLL]")
    add_line(lines, "Initial camera.mode=" .. safe_tostring(info.initial_mode))
    add_line(lines, "Final camera.mode=" .. safe_tostring(info.final_mode))
    add_line(lines, "Observed mode changes=" .. tostring(#mode_changes))
    for i, item in ipairs(mode_changes) do
        add_line(lines, string.format("%02d | elapsed_ms=%s | mode=%s", i, safe_tostring(item.elapsed), safe_tostring(item.value)))
    end
    add_line(lines, "")

    add_line(lines, "[EVENT SUMMARY]")
    add_line(lines, "Total callback invocations=" .. tostring(total_events))
    add_line(lines, "Events stored=" .. tostring(#stored_events))
    add_line(lines, "Events dropped=" .. tostring(dropped_events))
    add_line(lines, "Callback internal errors=" .. tostring(callback_errors))
    if callback_error_text ~= nil then
        add_line(lines, "Last callback error=" .. safe_tostring(callback_error_text))
    end
    add_line(lines, "")

    add_line(lines, "[RAW CALLBACK EVENTS]")
    if #stored_events == 0 then
        add_line(lines, "No callbacks received during capture window.")
    else
        for _, event in ipairs(stored_events) do
            add_line(lines, string.format(
                "%03d | %s | self=%s:%s | value=%s:%s",
                event.index,
                event.target,
                event.self_type,
                event.self_value,
                event.value_type,
                event.value
            ))
        end
    end
    add_line(lines, "")
    add_line(lines, "RECIPE_LAB_PROPERTY_WATCH_V04_END")
    return table.concat(lines, "\r\n") .. "\r\n"
end

local function save_report(report)
    local dir_ok, dir = pcall(function()
        return dryos.directory(LOG_DIR)
    end)
    if not dir_ok or dir == nil or dir.exists ~= true or dir.path == nil then
        return false, "LOG_DIR_UNAVAILABLE: " .. safe_tostring(dir)
    end

    local dir_path = safe_tostring(dir.path):gsub("\\", "/"):gsub("/+$", "")
    local path = dir_path .. "/" .. LOG_NAME
    local open_ok, file_or_error, open_error = pcall(io.open, path, "w")
    if not open_ok then
        return false, "LOG_OPEN_LUA_ERROR: " .. safe_tostring(file_or_error)
    end
    if file_or_error == nil then
        return false, "LOG_OPEN_FAILED: " .. safe_tostring(open_error)
    end

    local file = file_or_error
    local write_ok, write_result, write_error = pcall(function()
        return file:write(report)
    end)
    if not write_ok or write_result == nil then
        pcall(function() file:close() end)
        return false, "LOG_WRITE_FAILED: " .. safe_tostring(write_ok and write_error or write_result)
    end

    local flush_ok, flush_result, flush_error = pcall(function()
        return file:flush()
    end)
    if not flush_ok or flush_result == nil then
        pcall(function() file:close() end)
        return false, "LOG_FLUSH_FAILED: " .. safe_tostring(flush_ok and flush_error or flush_result)
    end

    local close_ok, close_result, close_error = pcall(function()
        return file:close()
    end)
    if not close_ok or close_result == nil then
        return false, "LOG_CLOSE_FAILED: " .. safe_tostring(close_ok and close_error or close_result)
    end

    local read_ok, read_file_or_error, read_error = pcall(io.open, path, "rb")
    if not read_ok or read_file_or_error == nil then
        return false, "LOG_READ_OPEN_FAILED: " .. safe_tostring(read_ok and read_error or read_file_or_error)
    end
    local read_file = read_file_or_error
    local contents_ok, contents = pcall(function()
        return read_file:read("*all")
    end)
    pcall(function() read_file:close() end)
    if not contents_ok or type(contents) ~= "string" then
        return false, "LOG_READ_FAILED: " .. safe_tostring(contents)
    end
    if contents ~= report then
        return false, "LOG_READBACK_MISMATCH: " .. tostring(#contents) .. " bytes"
    end

    return true, path .. " | " .. tostring(#contents) .. " bytes | readback verified"
end

local function run_watch()
    -- Run only after SET on the single Scripts entry. Close ML menu so the
    -- capture can continue while the user operates the camera normally.
    pcall(function() menu.close() end)

    total_events = 0
    stored_events = {}
    dropped_events = 0
    mode_changes = {}
    callback_errors = 0
    callback_error_text = nil
    attach_results = {}
    attached_targets = {}

    local targets = {
        { name = "SHOOTING_MODE [control]", object = property.SHOOTING_MODE, events = 0 },
        { name = "PICTURE_STYLE", object = property.PICTURE_STYLE, events = 0 },
        { name = "PC_FLAVOR1_PARAM", object = property.PC_FLAVOR1_PARAM, events = 0 },
        { name = "PC_FLAVOR2_PARAM", object = property.PC_FLAVOR2_PARAM, events = 0 },
        { name = "PC_FLAVOR3_PARAM", object = property.PC_FLAVOR3_PARAM, events = 0 }
    }

    console.clear()
    console.show()
    print("RECIPE LAB - PROPERTY WATCH v0.4")
    print("Five temporary property handlers will be tested.")
    print("No Picture Style parameters or camera settings are written.")
    print("")
    print("Registering handlers...")

    attach_handlers(targets)

    print("Verified handlers: " .. tostring(#attached_targets) .. "/5")
    for _, target in ipairs(targets) do
        print(target.name .. ": " .. safe_tostring(target.attach_status))
    end

    if #attached_targets == 0 then
        print("")
        print("No handlers were attached. Capture aborted.")
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end

    local info = { initial_mode = "?", final_mode = "?" }
    local mode_ok, mode_value = pcall(function() return camera.mode end)
    if mode_ok then
        info.initial_mode = safe_tostring(mode_value)
        info.final_mode = safe_tostring(mode_value)
    end

    console.clear()
    print("PROPERTY WATCH ACTIVE")
    print("")
    print("For the next 30 seconds:")
    print("1. Turn the mode dial P -> Av -> P a few times.")
    print("   This is the known-good SHOOTING_MODE control.")
    print("2. Return to P, open the Picture Style menu.")
    print("3. Press SET to select Standard, then User Def. 1,")
    print("   User Def. 2 and User Def. 3. Do not edit parameters.")
    print("4. Restore your original Picture Style afterwards.")
    print("")
    print("Capture starts in 5 seconds. The script will yield")
    print("so the property callback dispatcher can run.")
    task.yield(5000)
    console.hide()

    local elapsed = 0
    local last_mode = mode_ok and mode_value or nil
    while elapsed < CAPTURE_MS do
        -- Do not replace this with msleep(): task.yield() releases the shared
        -- Lua-state semaphore to the property-dispatch task.
        task.yield(POLL_MS)
        elapsed = elapsed + POLL_MS

        local poll_ok, polled_mode = pcall(function() return camera.mode end)
        if poll_ok then
            if last_mode == nil then
                last_mode = polled_mode
                info.initial_mode = safe_tostring(polled_mode)
            elseif polled_mode ~= last_mode then
                if #mode_changes < MAX_MODE_CHANGES then
                    mode_changes[#mode_changes + 1] = { elapsed = elapsed, value = polled_mode }
                end
                last_mode = polled_mode
            end
            info.final_mode = safe_tostring(polled_mode)
        end
    end

    detach_handlers()
    task.yield(500) -- allow already queued notifications to finish

    local report = build_report(targets, info)
    local save_ok, save_result = save_report(report)

    console.show()
    console.clear()
    print("RECIPE LAB - PROPERTY WATCH COMPLETE")
    print("Verified handlers: " .. tostring(#attached_targets))
    print("Mode changes: " .. tostring(#mode_changes))
    print("Total callbacks: " .. tostring(total_events))
    print("Callback errors: " .. tostring(callback_errors))
    print("")
    if save_ok then
        print("REPORT SAVE: VERIFIED")
        print("Path: " .. safe_tostring(save_result))
        print("Retrieve: ML/LOGS/" .. LOG_NAME)
    else
        print("REPORT SAVE: FAILED")
        print(safe_tostring(save_result))
    end
    print("")
    print("All temporary handlers have been detached.")
    print("No Picture Style parameters were written.")
    print("Press any key to return.")
    key.wait()
    console.hide()
end

-- Single action under Scripts. Press SET to run; MENU/Q does not execute it.
local test_menu = menu.new {
    parent = "Scripts",
    name = "Recipe Lab - Property Watch v0.4",
    help = "PRESS SET to monitor SHOOTING_MODE and Picture Style property callbacks for 30 seconds.",
    select = function(this)
        task.create(run_watch)
    end
}

print("Recipe Lab - Property Watch v0.4 loaded. Press SET on its Scripts entry to run.")
