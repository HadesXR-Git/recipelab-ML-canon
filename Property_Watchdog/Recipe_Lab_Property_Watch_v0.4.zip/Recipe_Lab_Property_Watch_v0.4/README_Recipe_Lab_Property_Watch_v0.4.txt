RECIPE LAB - PROPERTY WATCH v0.4
Target: Canon EOS 700D / firmware 1.1.5
Magic Lantern: Nightly.2018Jul03.700D115 (Crop Mood)

PURPOSE
This is the same passive property-watch test as v0.3, shortened to a
30-second capture window at the user's request. It watches SHOOTING_MODE
plus the four Picture Style properties in one run.

INSTALLATION
1. Copy recipe_lab_property_watch_v0.4.lua to:
   ML/SCRIPTS/recipe_lab_property_watch_v0.4.lua
2. Safely eject the SD card and put it in the EOS 700D.
3. Boot Magic Lantern and open ML > Scripts.
4. Highlight "Recipe Lab - Property Watch v0.4" and press SET.
   Do not simply exit the ML menu; SET launches the test.

TEST (30 SECONDS)
1. Turn the mode dial P -> Av -> P a few times. This tests the known-good
   SHOOTING_MODE control listener.
2. Return to P, open the Canon Picture Style menu.
3. Press SET to select Standard, then User Defined 1, User Defined 2,
   and User Defined 3. Do not edit any custom profile parameters.
4. Restore the Picture Style that was active before the test.

The script has a 5-second start countdown, followed by 30 seconds of capture.

OUTPUT
The report is written and read-back verified at:
ML/LOGS/RLPCH04.TXT

WHAT IT DOES
- Attaches temporary Lua property handlers to SHOOTING_MODE, PICTURE_STYLE,
  PC_FLAVOR1_PARAM, PC_FLAVOR2_PARAM, and PC_FLAVOR3_PARAM.
- Checks each handler by reading it back and comparing it with the callback.
- Uses task.yield() in the capture loop so the property dispatcher can run.
- Polls camera.mode independently as a control.
- Records raw callback arguments and per-property counts.
- Detaches every handler that this script attached before saving the report.

SAFETY
- Does not call property:request_change().
- Does not call dryos.call().
- Does not write Picture Style properties or camera settings.
- Does not overwrite a property if it already has a Lua function handler.
- If the script is interrupted or the camera loses power before completion,
  the report may not be written. Rebooting clears the temporary Lua handlers.

NOTE
The earlier successful SHOOTING_MODE test recorded twice as many callbacks as
polled mode transitions. This version preserves raw callback events rather than
assuming those repeated notifications are redundant.
