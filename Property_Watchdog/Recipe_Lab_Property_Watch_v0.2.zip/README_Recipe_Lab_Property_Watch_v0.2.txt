RECIPE LAB - PASSIVE PROPERTY WATCH v0.2
Target: Canon EOS 700D, firmware 1.1.5
Magic Lantern: Nightly.2018Jul03.700D115 (Crop Mood)

PURPOSE
This diagnostic checks whether Lua property handlers receive notifications for:
  - SHOOTING_MODE (control property already used by this build's copy2m.lua)
  - PICTURE_STYLE
  - PC_FLAVOR1_PARAM
  - PC_FLAVOR2_PARAM
  - PC_FLAVOR3_PARAM

WHAT CHANGED FROM v0.1
  - Per-run counters and arrays are reset before every capture. This fixes the
    cumulative 4, 8, 12, 16 listener count seen after rerunning v0.1.
  - Adds SHOOTING_MODE as a known-good control notification.
  - Captures the third io.open return value so the real filesystem error is shown.
  - Tries the directory object's resolved path, then B:/ML/LOGS, then ML/LOGS.
  - Reopens the saved report and verifies its exact contents and sentinel.

INSTALL
1. Copy recipe_lab_property_watch_v0.2.lua into ML/SCRIPTS/.
2. Keep Recipe Lab Browser v0.6 unchanged.
3. Restart/reload Lua scripts.
4. Open Scripts > Recipe Lab - Property Watch v0.2.

TEST (45 seconds)
1. Start the watcher.
2. Turn the mode dial P -> Av -> P. This is the control test; return to P.
3. Open the Canon Picture Style menu.
4. Press SET to actually select Standard, then User Def. 1, User Def. 2,
   and User Def. 3. Merely highlighting rows may not commit a selection.
5. Restore the original active Picture Style. Do not edit any profile parameters.

OUTPUT
Verified report:
  ML/LOGS/RLPCH02.TXT

If logging fails, the camera displays each attempted path and its actual io.open
error. Photograph that error screen instead of searching for a missing file.

SAFETY
The script does not call property:request_change(), dryos.call(), or any firmware
address. It only temporarily assigns Lua property handlers and clears them after
the capture. It does not write Picture Style parameters or import PF2/PF3 files.
