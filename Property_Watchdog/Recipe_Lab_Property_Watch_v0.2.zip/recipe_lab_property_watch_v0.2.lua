-- Recipe Lab - Passive Picture Style Property Watcher v0.2
-- Target: Canon EOS 700D / firmware 1.1.5 / ML Nightly.2018Jul03.700D115
--
-- v0.2 fixes:
--   * Resets all per-run counters/tables (v0.1 accumulated listener count on reruns).
--   * Adds SHOOTING_MODE as a known-good control property from bundled copy2m.lua.
--   * Captures BOTH error returns from io.open and uses explicit path fallbacks.
--   * Verifies report by reopening and checking a sentinel.
--
-- Safety:
--   * Does NOT call property:request_change() or dryos.call().
--   * Does NOT write camera properties or Picture Style parameters.
--   * Only temporarily installs property handlers, then removes them.

local LOG_DIR = "ML/LOGS"
local LOG_NAME = "RLPCH02.TXT" -- FAT 8.3 compatible
local CAPTURE_MS = 45000
local MAX_EVENTS = 100
local END_MARKER = "RECIPE_LAB_PROPERTY_WATCH_V02_END"

local targets = {
    { name = "SHOOTING_MODE [control]", object = property.SHOOTING_MODE, control = true },
    { name = "PICTURE_STYLE", object = property.PICTURE_STYLE },
    { name = "PC_FLAVOR1_PARAM", object = property.PC_FLAVOR1_PARAM },
    { name = "PC_FLAVOR2_PARAM", object = property.PC_FLAVOR2_PARAM },
    { name = "PC_FLAVOR3_PARAM", object = property.PC_FLAVOR3_PARAM },
}

-- Per-run state. Reinitialized at the start of every capture.
local events = {}
local event_total = 0
local event_dropped = 0
local attach_results = {}
local attached = {}

local function safe_tostring(v)
    local ok, result = pcall(tostring, v)
    if ok then return result end
    return "<tostring-error>"
end

local function value_text(v)
    if v == nil then return "nil" end
    local s = safe_tostring(v)
    if #s > 90 then s = string.sub(s, 1, 90) .. "..." end
    return type(v) .. ":" .. s
end

local function add_event(name, a, b)
    event_total = event_total + 1
    if #events >= MAX_EVENTS then
        event_dropped = event_dropped + 1
        return
    end
    local stamp = "?"
    pcall(function() stamp = safe_tostring(dryos.ms_clock) end)
    events[#events + 1] = string.format(
        "%03d | %s | ms=%s | arg1=%s | arg2=%s",
        event_total, name, stamp, value_text(a), value_text(b)
    )
end

local function make_handler(name)
    -- Matches the convention used by the bundled copy2m.lua:
    -- handler(prop, value).
    return function(prop_arg, value_arg)
        pcall(function() add_event(name, prop_arg, value_arg) end)
    end
end

local function attach_handlers()
    for _, target in ipairs(targets) do
        local obj = target.object
        if obj == nil then
            attach_results[#attach_results + 1] = target.name .. " | object=nil | SKIPPED"
        else
            local id = "?"
            local old_handler = nil
            pcall(function() id = safe_tostring(obj._id) end)
            pcall(function() old_handler = obj.handler end)

            if type(old_handler) == "function" then
                attach_results[#attach_results + 1] = target.name .. " | id=" .. id .. " | existing Lua function handler | NOT REPLACED"
            else
                local callback = make_handler(target.name)
                local ok, err = pcall(function() obj.handler = callback end)
                if ok then
                    attached[#attached + 1] = target
                    attach_results[#attach_results + 1] = target.name .. " | id=" .. id .. " | prior handler=" .. value_text(old_handler) .. " | ASSIGNMENT OK"
                else
                    attach_results[#attach_results + 1] = target.name .. " | id=" .. id .. " | ATTACH FAILED: " .. safe_tostring(err)
                end
            end
        end
    end
end

local function detach_handlers()
    for i = #attached, 1, -1 do
        local target = attached[i]
        local ok, err = pcall(function() target.object.handler = nil end)
        attach_results[#attach_results + 1] = target.name .. " | detach call=" .. safe_tostring(ok)
        if not ok then
            attach_results[#attach_results + 1] = target.name .. " | detach error=" .. safe_tostring(err)
        end
    end
end

local function build_report()
    local lines = {}
    local function add(s) lines[#lines + 1] = s end

    add("RECIPE LAB - PASSIVE PROPERTY WATCH v0.2")
    add("Target: Canon EOS 700D / firmware 1.1.5")
    add("Build: ML Nightly.2018Jul03.700D115 (Crop Mood)")
    add("Mode: PASSIVE; no property setters or firmware calls")
    add("Expected handler targets: 5 (one known-good control + four Picture Style properties)")
    add("")

    add("[PROPERTY ATTACH / DETACH RESULTS]")
    for _, line in ipairs(attach_results) do add(line) end
    add("")

    add("[EVENT SUMMARY]")
    add("Events captured: " .. tostring(event_total))
    add("Events stored: " .. tostring(#events))
    add("Events dropped: " .. tostring(event_dropped))
    add("")

    add("[PROPERTY CHANGE EVENTS]")
    if #events == 0 then
        add("No notifications were received during the capture window.")
    else
        for _, line in ipairs(events) do add(line) end
    end
    add("")
    add(END_MARKER)
    return table.concat(lines, "\r\n") .. "\r\n"
end

local function normalize_path(path)
    local s = safe_tostring(path or "")
    s = string.gsub(s, "\\", "/")
    s = string.gsub(s, "/+$", "")
    return s
end

local function try_open(path, mode)
    -- Preserve all io.open returns: pcall_ok, file_handle, filesystem_error.
    local call_ok, file, io_err = pcall(io.open, path, mode)
    if call_ok and file ~= nil then
        return file, nil
    end
    if not call_ok then
        return nil, "Lua error: " .. safe_tostring(file)
    end
    return nil, safe_tostring(io_err)
end

local function write_and_verify(report)
    local candidates = {}
    local dir_ok, dir = pcall(function() return dryos.directory(LOG_DIR) end)
    if dir_ok and dir ~= nil and dir.path ~= nil then
        candidates[#candidates + 1] = normalize_path(dir.path) .. "/" .. LOG_NAME
    end
    -- Fallbacks based on the working paths used by the earlier filesystem probe.
    candidates[#candidates + 1] = "B:/ML/LOGS/" .. LOG_NAME
    candidates[#candidates + 1] = "ML/LOGS/" .. LOG_NAME

    local unique = {}
    local ordered = {}
    for _, path in ipairs(candidates) do
        if path ~= nil and path ~= "" and not unique[path] then
            unique[path] = true
            ordered[#ordered + 1] = path
        end
    end

    local errors = {}
    for _, path in ipairs(ordered) do
        local file, open_err = try_open(path, "w")
        if file ~= nil then
            local write_call_ok, write_result, write_err = pcall(function() return file:write(report) end)
            local flush_call_ok, flush_result, flush_err = pcall(function() return file:flush() end)
            local close_call_ok, close_result, close_err = pcall(function() return file:close() end)

            if not write_call_ok or write_result == nil then
                return false, "WRITE_FAILED path=" .. path .. " detail=" .. safe_tostring(write_call_ok and write_err or write_result)
            end
            if not flush_call_ok then
                return false, "FLUSH_FAILED path=" .. path .. " detail=" .. safe_tostring(flush_result)
            end
            if not close_call_ok then
                return false, "CLOSE_FAILED path=" .. path .. " detail=" .. safe_tostring(close_result)
            end

            local input, read_open_err = try_open(path, "rb")
            if input == nil then
                return false, "READBACK_OPEN_FAILED path=" .. path .. " detail=" .. safe_tostring(read_open_err)
            end
            local read_call_ok, contents = pcall(function() return input:read("*all") end)
            local read_close_call_ok, read_close_result = pcall(function() return input:close() end)
            if not read_call_ok or type(contents) ~= "string" then
                return false, "READBACK_FAILED path=" .. path .. " detail=" .. safe_tostring(contents)
            end
            if not read_close_call_ok then
                return false, "READBACK_CLOSE_FAILED path=" .. path .. " detail=" .. safe_tostring(read_close_result)
            end
            if contents ~= report or string.find(contents, END_MARKER, 1, true) == nil then
                return false, "READBACK_MISMATCH path=" .. path .. " bytes=" .. tostring(#contents)
            end
            return true, path .. " | bytes=" .. tostring(#contents)
        else
            errors[#errors + 1] = path .. " => " .. safe_tostring(open_err)
        end
    end

    return false, "LOG_OPEN_FAILED; attempts: " .. table.concat(errors, " || ")
end

local function reset_run_state()
    events = {}
    event_total = 0
    event_dropped = 0
    attach_results = {}
    attached = {}
end

local function run_watch()
    reset_run_state()
    console.show()
    console.clear()
    print("RECIPE LAB - PROPERTY WATCH v0.2")
    print("Registering 5 temporary property listeners...")
    attach_handlers()

    local attached_count = #attached
    print("Assignments accepted: " .. tostring(attached_count) .. "/5")
    print("")
    print("For the next 45 seconds:")
    print("1. Turn mode dial P -> Av -> P (control test).")
    print("2. Open Picture Style menu.")
    print("3. Press SET to select Standard, then User Def. 1, 2, 3.")
    print("   Restore your original Picture Style afterwards.")
    print("Do not edit profile parameters.")
    print("")
    print("Listening starts in 5 seconds...")
    msleep(5000)
    console.hide()

    local start_ok, capture_start = pcall(function() return dryos.ms_clock end)
    if not start_ok or type(capture_start) ~= "number" then capture_start = 0 end
    local elapsed = 0
    while elapsed < CAPTURE_MS do
        msleep(250)
        local clock_ok, now = pcall(function() return dryos.ms_clock end)
        if clock_ok and type(now) == "number" and capture_start ~= 0 then
            elapsed = now - capture_start
            if elapsed < 0 then elapsed = CAPTURE_MS end
        else
            elapsed = elapsed + 250
        end
    end

    detach_handlers()
    local report_ok, report = pcall(build_report)
    console.show()
    console.clear()
    if not report_ok then
        print("REPORT BUILD FAILED")
        print(safe_tostring(report))
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end

    local save_ok, save_result = write_and_verify(report)
    print("RECIPE LAB - PROPERTY WATCH COMPLETE")
    print("Property handler assignments: " .. tostring(attached_count) .. "/5")
    print("Events received: " .. tostring(event_total))
    print("Events stored: " .. tostring(#events))
    print("Handler removals attempted: " .. tostring(#attached))
    print("")
    if save_ok then
        print("REPORT SAVE: VERIFIED")
        print("Path: " .. safe_tostring(save_result))
        print("Retrieve: ML/LOGS/" .. LOG_NAME)
    else
        print("REPORT SAVE: FAILED")
        print(safe_tostring(save_result))
    end
    print("")
    print("No Picture Style parameters were changed.")
    print("Press any key to return.")
    key.wait()
    console.hide()
end

local watch_menu = menu.new {
    parent = "Scripts",
    name = "Recipe Lab - Property Watch v0.2",
    help = "Passive property listener test with a SHOOTING_MODE control property.",
    submenu = {
        {
            name = "Start 45-second property watch",
            help = "Switch P to Av and back, then select Picture Style slots without editing parameters.",
            select = function(this)
                task.create(run_watch)
            end
        },
        {
            name = "Safety information",
            help = "No property request_change, dryos.call, or Picture Style parameter writes are used."
        }
    }
}

print("Recipe Lab Property Watch v0.2 loaded. Open Scripts > Recipe Lab - Property Watch v0.2.")
