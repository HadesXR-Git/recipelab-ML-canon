-- Recipe Lab - SHOOTING_MODE handler diagnostic v0.3
-- Target: Canon EOS 700D / firmware 1.1.5 / ML Nightly.2018Jul03.700D115
--
-- This is a narrow diagnostic. It attaches ONE temporary Lua property handler
-- to SHOOTING_MODE, checks that the handler can be read back, and independently
-- polls camera.mode. It does not write camera or Picture Style properties.
--
-- Output: ML/LOGS/RLMODE03.TXT

local LOG_DIR = "ML/LOGS"
local LOG_NAME = "RLMODE03.TXT" -- strict FAT 8.3
local CAPTURE_MS = 60000
local POLL_MS = 250
local MAX_EVENTS = 40
local MAX_MODE_CHANGES = 40

local event_total = 0
local events = {}
local mode_changes = {}
local handler_callback_error = nil
local callback = nil

local function safe_tostring(value)
    local ok, result = pcall(tostring, value)
    if ok then return result end
    return "<tostring-error>"
end

local function safe_type(value)
    local ok, result = pcall(type, value)
    if ok then return result end
    return "<type-error>"
end

local function add_line(lines, value)
    lines[#lines + 1] = safe_tostring(value)
end

-- Match the callback signature used by the bundled ML example copy2m.lua:
-- function handler(self, value)
local function shooting_mode_handler(self, value)
    -- Increment BEFORE any formatting or string conversion. If this callback
    -- executes, the count changes even if later diagnostics fail.
    event_total = event_total + 1

    if #events < MAX_EVENTS then
        events[#events + 1] = {
            value_type = safe_type(value),
            value = value
        }
    end
end

local function build_report(info)
    local lines = {}
    add_line(lines, "RECIPE LAB - SHOOTING_MODE HANDLER TEST v0.3")
    add_line(lines, "Target: Canon EOS 700D / firmware 1.1.5")
    add_line(lines, "Build: ML Nightly.2018Jul03.700D115 (Crop Mood)")
    add_line(lines, "Mode: READ-ONLY camera polling + one temporary Lua property handler")
    add_line(lines, "No Picture Style properties or camera settings are written.")
    add_line(lines, "")

    add_line(lines, "[HANDLER REGISTRATION]")
    add_line(lines, "Property object exists: " .. safe_tostring(info.object_exists))
    add_line(lines, "Property _id: " .. safe_tostring(info.prop_id))
    add_line(lines, "Handler before assignment: type=" .. safe_tostring(info.before_type) .. " value=" .. safe_tostring(info.before_value))
    add_line(lines, "Assignment pcall success: " .. safe_tostring(info.assign_ok))
    add_line(lines, "Assignment error: " .. safe_tostring(info.assign_error))
    add_line(lines, "Handler readback pcall success: " .. safe_tostring(info.readback_ok))
    add_line(lines, "Handler readback type: " .. safe_tostring(info.readback_type))
    add_line(lines, "Handler readback is same Lua function: " .. safe_tostring(info.readback_same))
    add_line(lines, "")

    add_line(lines, "[CAMERA.MODE POLL]")
    add_line(lines, "Initial camera.mode: " .. safe_tostring(info.initial_mode))
    add_line(lines, "Final camera.mode: " .. safe_tostring(info.final_mode))
    add_line(lines, "Observed camera.mode changes: " .. tostring(#mode_changes))
    if #mode_changes == 0 then
        add_line(lines, "No camera.mode changes were observed by polling.")
    else
        for i, item in ipairs(mode_changes) do
            add_line(lines, string.format("%02d | elapsed_ms=%s | mode=%s", i, safe_tostring(item.elapsed), safe_tostring(item.value)))
        end
    end
    add_line(lines, "")

    add_line(lines, "[SHOOTING_MODE CALLBACK]")
    add_line(lines, "Callback invocations: " .. tostring(event_total))
    add_line(lines, "Callback values stored: " .. tostring(#events))
    if handler_callback_error ~= nil then
        add_line(lines, "Callback diagnostic error: " .. safe_tostring(handler_callback_error))
    end
    if #events == 0 then
        add_line(lines, "No callback invocation was recorded.")
    else
        for i, item in ipairs(events) do
            add_line(lines, string.format("%02d | type=%s | value=%s", i, safe_tostring(item.value_type), safe_tostring(item.value)))
        end
    end
    add_line(lines, "")
    add_line(lines, "RECIPE_LAB_SHOOTING_MODE_V03_END")
    return table.concat(lines, "\r\n") .. "\r\n"
end

local function save_report(report)
    local dir_ok, dir = pcall(function() return dryos.directory(LOG_DIR) end)
    if not dir_ok or dir == nil or dir.exists ~= true or dir.path == nil then
        return false, "LOG_DIR_UNAVAILABLE: " .. safe_tostring(dir)
    end

    local dir_path = safe_tostring(dir.path):gsub("\\", "/"):gsub("/+$", "")
    local path = dir_path .. "/" .. LOG_NAME
    local open_ok, file_or_error, open_error = pcall(io.open, path, "w")
    if not open_ok then
        return false, "LOG_OPEN_LUA_ERROR: " .. safe_tostring(file_or_error)
    end
    if file_or_error == nil then
        return false, "LOG_OPEN_FAILED: " .. safe_tostring(open_error)
    end

    local file = file_or_error
    local write_ok, write_result, write_error = pcall(function() return file:write(report) end)
    if not write_ok or write_result == nil then
        pcall(function() file:close() end)
        return false, "LOG_WRITE_FAILED: " .. safe_tostring(write_ok and write_error or write_result)
    end

    local flush_ok, flush_result, flush_error = pcall(function() return file:flush() end)
    if not flush_ok or flush_result == nil then
        pcall(function() file:close() end)
        return false, "LOG_FLUSH_FAILED: " .. safe_tostring(flush_ok and flush_error or flush_result)
    end

    local close_ok, close_result, close_error = pcall(function() return file:close() end)
    if not close_ok or close_result == nil then
        return false, "LOG_CLOSE_FAILED: " .. safe_tostring(close_ok and close_error or close_result)
    end

    local read_ok, read_file_or_error, read_error = pcall(io.open, path, "rb")
    if not read_ok or read_file_or_error == nil then
        return false, "LOG_READ_OPEN_FAILED: " .. safe_tostring(read_ok and read_error or read_file_or_error)
    end
    local read_file = read_file_or_error
    local contents_ok, contents = pcall(function() return read_file:read("*all") end)
    pcall(function() read_file:close() end)
    if not contents_ok or type(contents) ~= "string" then
        return false, "LOG_READ_FAILED: " .. safe_tostring(contents)
    end
    if contents ~= report then
        return false, "LOG_READBACK_MISMATCH: " .. tostring(#contents) .. " bytes"
    end

    return true, path .. " | " .. tostring(#contents) .. " bytes | readback verified"
end

local function run_test()
    event_total = 0
    events = {}
    mode_changes = {}
    handler_callback_error = nil

    console.clear()
    console.show()
    print("RECIPE LAB - SHOOTING_MODE TEST v0.3")
    print("Only one temporary property handler will be installed.")
    print("No camera settings or Picture Style values will be changed.")
    print("")

    local object = property.SHOOTING_MODE
    if object == nil then
        print("ABORT: property.SHOOTING_MODE is nil.")
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end

    local info = {
        object_exists = true,
        prop_id = "?",
        before_type = "?",
        before_value = "?",
        assign_ok = false,
        assign_error = "none",
        readback_ok = false,
        readback_type = "?",
        readback_same = false,
        initial_mode = "?",
        final_mode = "?"
    }

    pcall(function() info.prop_id = object._id end)
    local before_ok, before_value = pcall(function() return object.handler end)
    if before_ok then
        info.before_type = safe_type(before_value)
        info.before_value = safe_tostring(before_value)
    else
        info.before_type = "read-error"
        info.before_value = safe_tostring(before_value)
    end

    -- Do not overwrite another script's active Lua handler.
    if before_ok and safe_type(before_value) == "function" then
        print("ABORT: SHOOTING_MODE already has a Lua function handler.")
        print("No handler was replaced and no settings were changed.")
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end

    local mode_ok, mode_value = pcall(function() return camera.mode end)
    if mode_ok then info.initial_mode = safe_tostring(mode_value) end

    callback = shooting_mode_handler
    local assign_ok, assign_error = pcall(function() object.handler = callback end)
    info.assign_ok = assign_ok
    if not assign_ok then info.assign_error = safe_tostring(assign_error) end

    local readback_ok, readback_value = pcall(function() return object.handler end)
    info.readback_ok = readback_ok
    if readback_ok then
        info.readback_type = safe_type(readback_value)
        info.readback_same = (readback_value == callback)
    else
        info.readback_type = "read-error"
        info.readback_same = false
    end

    if not assign_ok or not readback_ok or info.readback_type ~= "function" then
        pcall(function() object.handler = nil end)
        console.clear()
        print("HANDLER REGISTRATION NOT VERIFIED")
        print("Assignment call: " .. safe_tostring(assign_ok))
        print("Readback type: " .. safe_tostring(info.readback_type))
        print("Same callback: " .. safe_tostring(info.readback_same))
        print("No capture was started.")
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end

    console.clear()
    print("HANDLER READBACK VERIFIED: function")
    print("Same Lua callback: " .. safe_tostring(info.readback_same))
    print("")
    print("For the next 60 seconds:")
    print("1. Turn the mode dial P -> Av -> P several times.")
    print("2. Pause briefly at Av before returning to P.")
    print("3. Do not change Picture Style settings.")
    print("")
    print("Camera mode is also being polled independently.")
    print("Capture begins in 5 seconds...")
    msleep(5000)
    console.hide()

    local elapsed = 0
    local last_mode = mode_value
    while elapsed < CAPTURE_MS do
        msleep(POLL_MS)
        elapsed = elapsed + POLL_MS
        local poll_ok, polled_mode = pcall(function() return camera.mode end)
        if poll_ok then
            if last_mode == nil then
                last_mode = polled_mode
                info.initial_mode = safe_tostring(polled_mode)
            elseif polled_mode ~= last_mode then
                if #mode_changes < MAX_MODE_CHANGES then
                    mode_changes[#mode_changes + 1] = { elapsed = elapsed, value = polled_mode }
                end
                last_mode = polled_mode
            end
            info.final_mode = safe_tostring(polled_mode)
        end
    end

    local detach_ok, detach_error = pcall(function() object.handler = nil end)
    msleep(500) -- allow any already queued notification to drain

    local report = build_report(info)
    local save_ok, save_result = save_report(report)

    console.show()
    console.clear()
    print("RECIPE LAB - SHOOTING_MODE TEST COMPLETE")
    print("Handler readback: " .. safe_tostring(info.readback_type))
    print("Same callback: " .. safe_tostring(info.readback_same))
    print("camera.mode changes: " .. tostring(#mode_changes))
    print("Handler callbacks: " .. tostring(event_total))
    print("Handler detached: " .. safe_tostring(detach_ok))
    if not detach_ok then print("Detach error: " .. safe_tostring(detach_error)) end
    print("")
    if save_ok then
        print("REPORT SAVE: VERIFIED")
        print("Path: " .. safe_tostring(save_result))
        print("Retrieve: ML/LOGS/" .. LOG_NAME)
    else
        print("REPORT SAVE: FAILED")
        print(safe_tostring(save_result))
    end
    print("")
    print("No Picture Style values were changed.")
    print("Press any key to return.")
    key.wait()
    console.hide()
end

local test_menu = menu.new {
    parent = "Scripts",
    name = "Recipe Lab - Mode Handler Test v0.3",
    help = "Checks SHOOTING_MODE handler readback against camera.mode polling.",
    submenu = {
        {
            name = "Start 60-second mode handler test",
            help = "Turn P -> Av -> P several times. No camera settings are written.",
            select = function(this)
                task.create(run_test)
            end
        },
        {
            name = "Safety information",
            help = "Only a temporary SHOOTING_MODE Lua callback is installed and removed."
        }
    }
}

print("Recipe Lab - Mode Handler Test v0.3 loaded.")
