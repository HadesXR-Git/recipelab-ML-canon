RECIPE LAB - SHOOTING_MODE HANDLER TEST v0.3
Target: Canon EOS 700D, firmware 1.1.5
Magic Lantern: Nightly.2018Jul03.700D115 (Crop Mood)

PURPOSE
This is a narrow diagnostic after Property Watch v0.2 recorded no callbacks.
It installs ONE temporary Lua handler on property.SHOOTING_MODE, reads the
handler back to confirm registration, and independently polls camera.mode.
This separates a property-notification problem from a test or callback problem.

SAFETY
- Does not change camera.mode, exposure, Picture Style, or any camera property.
- Does not call property:request_change(), dryos.call(), or firmware addresses.
- Does not replace an already-visible Lua function handler.
- Removes its temporary SHOOTING_MODE handler when the test finishes.

INSTALL
1. Copy recipe_lab_mode_handler_test_v0.3.lua into ML/SCRIPTS/.
2. Leave Recipe Lab Browser v0.6 unchanged.
3. Reload/restart the Lua scripts.
4. Open Scripts > Recipe Lab - Mode Handler Test v0.3.

TEST
1. Start the 60-second test.
2. During the capture window, turn the mode dial P -> Av -> P several times.
3. Pause briefly at Av before returning to P.
4. Do not change any Picture Style values.

WHAT IT MEASURES
- Handler readback type and whether it is the same Lua callback.
- camera.mode changes detected by read-only polling.
- SHOOTING_MODE handler callback count and values.

OUTPUT
ML/LOGS/RLMODE03.TXT
The script writes the report and verifies it by reopening and comparing the
full contents. Retrieve the file after the script finishes.

INTERPRETATION
- camera.mode changes > 0 and callbacks > 0: handler delivery works.
- camera.mode changes > 0 and callbacks = 0, with handler readback=function:
  the Lua handler is registered, but SHOOTING_MODE notifications are not
  reaching this Lua callback on this build/test path.
- camera.mode changes = 0: the mode dial test was not observed by camera.mode,
  so the callback result is inconclusive.
- handler readback is not function: registration itself was not verified.
