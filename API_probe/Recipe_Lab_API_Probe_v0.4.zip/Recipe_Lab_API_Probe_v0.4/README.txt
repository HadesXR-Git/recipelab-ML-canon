RECIPE LAB - API PROBE v0.4
===========================

Target
------
Canon EOS 700D / firmware 1.1.5
Magic Lantern Nightly.2018Jul03.700D115 (Crop Mood)

Purpose
-------
Collect a more useful, read-only inventory of the Picture-Style-related Lua API
and save it using the already-tested ML/LOGS filesystem path.

What changed from earlier probes
---------------------------------
- Uses ML/LOGS, where RLBPROBE.TXT was successfully written and read back.
- Does not rely on pairs() to enumerate metatable-backed API tables.
- Reads selected documented lens fields directly.
- Checks the presence and _id values of Picture-Style-related property objects:
  PICTURE_STYLE, PC_FLAVOR1_PARAM, PC_FLAVOR2_PARAM, PC_FLAVOR3_PARAM, PICSTYLE.
- Records selected API member types and metatable __index/__newindex types.
- Reopens the log after writing and verifies a report sentinel and exact contents.

Output
------
SD:/ML/LOGS/RLB_API04.LOG

Install and run
---------------
1. Copy recipe_lab_api_probe_v0.4.lua into ML/SCRIPTS/.
2. Boot the camera and open Magic Lantern > Scripts.
3. Run "Recipe Lab - API Probe v0.4".
4. Select "Run read-only API probe".
5. Confirm the screen reports READBACK: VERIFIED.
6. Shut the camera down normally, remove the card and upload:
   ML/LOGS/RLB_API04.LOG

Safety
------
- Does not write Picture Style properties.
- Does not register property handlers.
- Does not invoke dryos.call().
- Does not invoke undocumented firmware functions.
- Writes one diagnostic text file in the existing ML/LOGS directory.
- Re-running overwrites only RLB_API04.LOG.

Interpretation
--------------
The log is a diagnostic inventory, not a PF2/PF3 loader. The direct lens field
values and property object IDs help us choose the next reverse-engineering step.
No profile registration or camera-setting changes are attempted.
