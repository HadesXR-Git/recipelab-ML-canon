-- Recipe Lab API Probe for Canon EOS 700D / Magic Lantern
-- Intended for Nightly.2018Jul03.700D115 (Crop Mood build).
-- READ-ONLY: this script only reads camera/API values and writes a text log.
-- It does NOT call firmware addresses, change properties, or apply Picture Styles.

local LOG_NAME = "RECIPE_LAB_PROBE.LOG"
local log_file = nil
local log_error = nil

local function safe_tostring(value)
    local ok, result = pcall(tostring, value)
    if ok then return result end
    return "<tostring error: " .. tostring(result) .. ">"
end

local function emit(message)
    message = safe_tostring(message)
    print(message)
    if log_file then
        pcall(function() log_file:write(message, "\n") end)
    end
end

local function safe_read(label, getter)
    local ok, value = pcall(getter)
    if ok then
        emit(label .. " = " .. safe_tostring(value) .. "  [" .. type(value) .. "]")
    else
        emit(label .. " = <unavailable: " .. safe_tostring(value) .. ">")
    end
end

local function matching_keys(label, object)
    emit("")
    emit(label .. " matching keys:")
    if object == nil then
        emit("  <object is nil>")
        return
    end

    local ok, err = pcall(function()
        local found = 0
        for key, value in pairs(object) do
            local key_text = safe_tostring(key)
            local lower = string.lower(key_text)
            if string.find(lower, "pic", 1, true)
                or string.find(lower, "style", 1, true)
                or string.find(lower, "pcset", 1, true)
                or string.find(lower, "flavor", 1, true) then
                emit("  " .. key_text .. " = " .. safe_tostring(value) .. "  [" .. type(value) .. "]")
                found = found + 1
            end
        end
        if found == 0 then emit("  <no matching enumerable keys>") end
    end)
    if not ok then emit("  <enumeration unavailable: " .. safe_tostring(err) .. ">") end
end

local function describe_object(label, object)
    emit("")
    emit(label .. " type: " .. type(object))
    local ok, mt = pcall(getmetatable, object)
    if ok then emit(label .. " metatable: " .. safe_tostring(mt) .. "  [" .. type(mt) .. "]")
    else emit(label .. " metatable: <unavailable>") end
    matching_keys(label, object)
end

local function run_probe()
    menu.close()
    console.clear()
    console.show()

    local open_ok, file_or_error = pcall(io.open, LOG_NAME, "a")
    if open_ok and file_or_error then
        log_file = file_or_error
        pcall(function()
            log_file:write("\n============================================================\n")
            log_file:write("Recipe Lab API Probe - read-only run\n")
            log_file:write("============================================================\n")
        end)
    else
        log_error = open_ok and "io.open returned nil" or safe_tostring(file_or_error)
    end

    emit("RECIPE LAB - API PROBE (READ ONLY)")
    emit("Camera: Canon EOS 700D / Magic Lantern Nightly.2018Jul03.700D115")
    emit("This probe will not change camera settings or call firmware addresses.")
    if log_error then emit("Log file could not be opened: " .. log_error)
    else emit("Log file: " .. LOG_NAME .. " (SD-card root)") end

    emit("")
    emit("CAMERA")
    safe_read("camera.model", function() return camera.model end)
    safe_read("camera.model_short", function() return camera.model_short end)
    safe_read("camera.firmware", function() return camera.firmware end)
    safe_read("camera.mode", function() return camera.mode end)

    emit("")
    emit("CURRENT PICTURE STYLE VALUES (GET ONLY)")
    safe_read("lens.picstyle", function() return lens.picstyle end)
    safe_read("lens.raw_picstyle", function() return lens.raw_picstyle end)
    safe_read("lens.contrast", function() return lens.contrast end)
    safe_read("lens.sharpness", function() return lens.sharpness end)
    safe_read("lens.saturation", function() return lens.saturation end)
    safe_read("lens.color_tone", function() return lens.color_tone end)

    emit("")
    emit("AVAILABLE API MEMBERS (FILTERED; NO FUNCTIONS CALLED)")
    describe_object("lens", lens)
    describe_object("property", property)
    describe_object("event", event)
    describe_object("dryos", dryos)

    emit("")
    emit("END OF PROBE")
    emit("No Picture Style properties were written.")
    emit("No PF2/PF3 profile was opened, parsed, or applied by this probe.")
    emit("Press any key to return.")

    if log_file then
        pcall(function()
            log_file:flush()
            log_file:close()
        end)
        log_file = nil
    end

    key.wait()
    console.hide()
end

local probe_menu = menu.new {
    parent = "Scripts",
    name = "Recipe Lab - API Probe",
    help = "Read-only inventory of Picture Style API members and current values.",
    submenu = {
        {
            name = "Run read-only probe",
            help = "Reads lens/property/event/dryos API members; writes RECIPE_LAB_PROBE.LOG.",
            select = function(this)
                task.create(run_probe)
            end
        },
        {
            name = "Safety: read-only",
            help = "No property setters, firmware calls, or Picture Style writes are used."
        }
    }
}

print("Recipe Lab API Probe loaded. Open Scripts > Recipe Lab - API Probe.")
