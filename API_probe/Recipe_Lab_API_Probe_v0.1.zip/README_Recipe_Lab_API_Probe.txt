RECIPE LAB - API PROBE (READ-ONLY)
=================================

Target:
  Canon EOS 700D
  Canon firmware 1.1.5
  Magic Lantern Nightly.2018Jul03.700D115 (Crop Mood)

Purpose:
  Inventory the live Lua API and read the current Picture Style values.
  This gives us a build-specific baseline before writing any native code.

Safety:
  - Read-only with respect to camera settings.
  - Does not invoke dryos.call() or any firmware address.
  - Does not call property setters or event/property write functions.
  - Does not register, overwrite, or apply a Picture Style.
  - Writes only a diagnostic text file named RECIPE_LAB_PROBE.LOG
    in the SD-card root (append mode).

Install:
  1. Copy recipe_lab_api_probe.lua to ML/SCRIPTS/.
  2. Safely eject the card and boot the camera.
  3. Open Magic Lantern > Scripts.
  4. Open "Recipe Lab - API Probe".
  5. Select "Run read-only probe".
  6. Wait for the report, then press any key to return.
  7. Retrieve RECIPE_LAB_PROBE.LOG from the SD-card root and send it back.

Please do not run api_test.lua as a substitute. That bundled script runs
additional tests which change exposure, autofocus, and LiveView state.

This probe does not prove that the camera can import PF2/PF3 from SD. It only
reports the read-only Lua surface available in this specific firmware build.
