-- Recipe Lab API Probe v0.2
-- Target: Canon EOS 700D, firmware 1.1.5, ML Nightly.2018Jul03.700D115
-- READ-ONLY with respect to camera properties and Picture Styles.
-- Writes a diagnostic text file to the SD-card root using an explicit path.

local LOG_NAME = "RECIPE_LAB_PROBE.LOG"
local log_file = nil
local log_path = nil
local log_write_error = nil
local log_error = nil
local root_path = nil

local function safe_tostring(value)
    local ok, result = pcall(tostring, value)
    if ok then return result end
    return "<tostring error>"
end

local function normalize_path(path)
    return tostring(path or ""):gsub("\\", "/")
end

local function with_trailing_slash(path)
    path = normalize_path(path)
    if path ~= "" and string.sub(path, -1) ~= "/" then
        path = path .. "/"
    end
    return path
end

-- Use the exact directory-navigation method already proven by Recipe Lab:
-- ML/SCRIPTS -> parent (ML) -> parent (card root).
local function resolve_card_root()
    local ok, anchor = pcall(function()
        return dryos.directory("ML/SCRIPTS")
    end)
    if not ok then
        return nil, "dryos.directory(ML/SCRIPTS) error: " .. safe_tostring(anchor)
    end
    if anchor == nil or anchor.exists ~= true then
        return nil, "ML/SCRIPTS anchor unavailable (exists=" .. safe_tostring(anchor and anchor.exists) .. ")"
    end

    local ml_dir = anchor.parent
    if ml_dir == nil then return nil, "ML/SCRIPTS has no parent directory" end

    local root_dir = ml_dir.parent
    if root_dir == nil then return nil, "ML has no parent directory" end
    if root_dir.exists ~= true then
        return nil, "Card-root directory reports exists=" .. safe_tostring(root_dir.exists)
    end
    if root_dir.path == nil then return nil, "Card-root directory has no path property" end

    return root_dir, nil
end

local function emit(message)
    message = safe_tostring(message)
    print(message)

    if log_file ~= nil and log_write_error == nil then
        local ok, result, write_err = pcall(function()
            return log_file:write(message, "\r\n")
        end)
        if not ok then
            log_write_error = safe_tostring(result)
            print("LOG WRITE ERROR: " .. log_write_error)
        elseif result == nil then
            log_write_error = safe_tostring(write_err or "write returned nil")
            print("LOG WRITE ERROR: " .. log_write_error)
        end
    end
end

local function safe_read(label, getter)
    local ok, value = pcall(getter)
    if ok then
        emit(label .. " = " .. safe_tostring(value) .. " [" .. type(value) .. "]")
    else
        emit(label .. " = <unavailable: " .. safe_tostring(value) .. ">")
    end
end

local function matching_keys(label, object)
    emit("")
    emit(label .. " matching enumerable keys:")
    if object == nil then
        emit("  <object is nil>")
        return
    end

    local ok, err = pcall(function()
        local found = 0
        for key, value in pairs(object) do
            local key_text = safe_tostring(key)
            local lower = string.lower(key_text)
            if string.find(lower, "pic", 1, true)
                or string.find(lower, "style", 1, true)
                or string.find(lower, "pcset", 1, true)
                or string.find(lower, "flavor", 1, true) then
                emit("  " .. key_text .. " = " .. safe_tostring(value) .. " [" .. type(value) .. "]")
                found = found + 1
            end
        end
        if found == 0 then emit("  <no matching enumerable keys>") end
    end)
    if not ok then emit("  <enumeration unavailable: " .. safe_tostring(err) .. ">") end
end

local function describe_object(label, object)
    emit("")
    emit(label .. " type: " .. type(object))
    local ok, mt = pcall(getmetatable, object)
    if ok then
        emit(label .. " metatable: " .. safe_tostring(mt) .. " [" .. type(mt) .. "]")
    else
        emit(label .. " metatable: <unavailable>")
    end
    matching_keys(label, object)
end

local function open_root_log()
    local root_dir, root_error = resolve_card_root()
    if root_dir == nil then
        return nil, nil, root_error
    end

    root_path = with_trailing_slash(root_dir.path)
    log_path = root_path .. LOG_NAME

    local ok, file_or_error = pcall(io.open, log_path, "w")
    if not ok then
        return nil, log_path, "io.open raised: " .. safe_tostring(file_or_error)
    end
    if file_or_error == nil then
        return nil, log_path, "io.open returned nil (check card path/write access)"
    end

    return file_or_error, log_path, nil
end

local function close_log()
    if log_file == nil then return end

    if log_write_error == nil then
        local ok, result, flush_err = pcall(function()
            return log_file:flush()
        end)
        if not ok then
            log_write_error = "flush error: " .. safe_tostring(result)
        elseif result == nil then
            log_write_error = "flush failed: " .. safe_tostring(flush_err)
        end
    end

    local ok, err = pcall(function() log_file:close() end)
    log_file = nil
    if not ok then
        if log_write_error == nil then log_write_error = "close error: " .. safe_tostring(err) end
    end
end

local function run_probe()
    menu.close()
    console.clear()
    console.show()

    log_file, log_path, log_error = open_root_log()

    emit("RECIPE LAB - API PROBE v0.2 (READ ONLY)")
    emit("Camera target: Canon EOS 700D / firmware 1.1.5")
    emit("ML target: Nightly.2018Jul03.700D115")
    emit("No camera properties or Picture Styles will be changed.")
    emit("")

    if log_file ~= nil then
        emit("LOG OPEN: OK")
        emit("LOG PATH: " .. log_path)
        -- Flush the header immediately so a file is created even if a later
        -- getter causes an unexpected error.
        local ok, result, flush_err = pcall(function()
            log_file:write("Recipe Lab API Probe v0.2\r\n")
            return log_file:flush()
        end)
        if not ok then
            log_write_error = safe_tostring(result)
            print("LOG INITIAL WRITE ERROR: " .. log_write_error)
        elseif result == nil then
            log_write_error = safe_tostring(flush_err or "flush returned nil")
            print("LOG INITIAL FLUSH ERROR: " .. log_write_error)
        end
    else
        emit("LOG OPEN: FAILED")
        emit("LOG TARGET: " .. safe_tostring(log_path or "(card root unavailable)"))
        emit("LOG ERROR: " .. safe_tostring(log_error))
    end

    emit("")
    emit("CARD ROOT")
    emit("Resolved root path: " .. safe_tostring(root_path or "(unavailable)"))

    emit("")
    emit("CAMERA")
    safe_read("camera.model", function() return camera.model end)
    safe_read("camera.model_short", function() return camera.model_short end)
    safe_read("camera.firmware", function() return camera.firmware end)
    safe_read("camera.mode", function() return camera.mode end)

    emit("")
    emit("CURRENT PICTURE STYLE VALUES (GET ONLY)")
    safe_read("lens.picstyle", function() return lens.picstyle end)
    safe_read("lens.raw_picstyle", function() return lens.raw_picstyle end)
    safe_read("lens.contrast", function() return lens.contrast end)
    safe_read("lens.sharpness", function() return lens.sharpness end)
    safe_read("lens.saturation", function() return lens.saturation end)
    safe_read("lens.color_tone", function() return lens.color_tone end)

    emit("")
    emit("API OBJECTS")
    describe_object("lens", lens)
    describe_object("property", property)
    describe_object("event", event)
    describe_object("dryos", dryos)

    close_log()

    emit("")
    if log_path ~= nil and log_write_error == nil then
        print("LOG SAVE: OK")
        print("Saved to: " .. log_path)
    elseif log_path ~= nil then
        print("LOG SAVE: FAILED")
        print("Write/flush/close error: " .. safe_tostring(log_write_error))
    else
        print("LOG SAVE: FAILED - card root could not be resolved")
    end
    print("No PF2/PF3 file was opened or parsed.")
    print("Press any key to return.")

    key.wait()
    console.hide()
end

local probe_menu = menu.new {
    parent = "Scripts",
    name = "Recipe Lab - API Probe v0.2",
    help = "Read-only API inventory; writes its log using the explicit SD-card root path.",
    submenu = {
        {
            name = "Run read-only probe",
            help = "Reads current API values and saves RECIPE_LAB_PROBE.LOG to card root.",
            select = function(this)
                task.create(run_probe)
            end
        },
        {
            name = "Safety: read-only",
            help = "No property setters, firmware calls, or Picture Style writes are used."
        }
    }
}

print("Recipe Lab API Probe v0.2 loaded. Open Scripts > Recipe Lab - API Probe v0.2.")
