RECIPE LAB - API PROBE v0.2 (READ-ONLY)
======================================
Target:
  Canon EOS 700D, Canon firmware 1.1.5
  Magic Lantern Nightly.2018Jul03.700D115 (Crop Mood)

FIX IN V0.2
-----------
The previous probe used io.open("RECIPE_LAB_PROBE.LOG", "a"), a relative
path, while claiming that the file would be written to the SD-card root.
This version resolves the card root from the known-good directory chain:
  dryos.directory("ML/SCRIPTS").parent.parent
It then opens the explicit full path:
  <resolved card root>/RECIPE_LAB_PROBE.LOG

It also reports open, write, flush, and close failures on the camera screen.
The log header is flushed immediately after opening, so the file should exist
even if a later API read fails.

INSTALL
-------
1. Back up the SD card.
2. Extract this ZIP at the SD-card root. It adds:
     /ML/SCRIPTS/recipe_lab_api_probe.lua
3. Boot the camera and open Magic Lantern > Scripts.
4. Select "Recipe Lab - API Probe v0.2".
5. Select "Run read-only probe".
6. At the end, confirm the screen says "LOG SAVE: OK" and note the exact
   "Saved to:" path.
7. Retrieve RECIPE_LAB_PROBE.LOG from that exact path and send it back.

SAFETY
------
This probe only reads camera/API values. It does not call firmware addresses,
write camera properties, register a Picture Style, or open PF2/PF3 profiles.
It writes only a plain-text diagnostic log on the SD card.

If the screen reports LOG SAVE: FAILED, please photograph the lines showing
LOG TARGET and LOG ERROR / Write-flush-close error. Do not run other scripts
as a substitute.
