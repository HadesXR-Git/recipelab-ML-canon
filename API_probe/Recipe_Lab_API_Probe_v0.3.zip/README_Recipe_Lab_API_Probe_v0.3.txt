RECIPE LAB - FILESYSTEM PROBE v0.3
=================================

Target:
  Canon EOS 700D, firmware 1.1.5
  Magic Lantern Nightly.2018Jul03.700D115 (Crop Mood)

Purpose:
  The previous API probe displayed LOG SAVE: OK for B:/RECIPE_LAB_PROBE.LOG,
  but that message did not independently prove that the file could be found
  in the directory or reopened. This probe performs an explicit readback.

What it does:
  1. Opens the existing ML/LOGS directory.
  2. Creates/overwrites ML/LOGS/RLBPROBE.TXT (8.3-safe filename).
  3. Writes a known marker, calls flush(), and closes the file.
  4. Reopens ML/LOGS and checks its :files() listing for RLBPROBE.TXT.
  5. Reopens the file in binary read mode and compares its contents.
  6. Leaves the small test file in place for inspection on the computer.

Safety:
  - Does not change exposure, autofocus, LiveView, or Picture Style settings.
  - Does not call undocumented firmware addresses.
  - Writes only one small text file in the existing ML/LOGS folder.
  - Re-running the probe overwrites that same test file.

Install:
  1. Copy recipe_lab_api_probe_v0.3.lua to ML/SCRIPTS/.
  2. Boot the camera and open Magic Lantern > Scripts.
  3. Open "Recipe Lab - FS Probe v0.3".
  4. Select "Run filesystem write/readback test".
  5. Photograph the full report, especially sections 2, 3 and 4.
  6. Shut the camera down normally before removing the SD card.
  7. On the computer, check ML/LOGS/RLBPROBE.TXT.

Interpretation:
  - Listing=yes and readback=yes: the file exists and Lua can read it back.
  - Listing=no but readback=yes: directory enumeration and file lookup disagree.
  - Listing=no and readback fails: the earlier LOG SAVE result was not sufficient
    to prove a persistent file was created.
  - Camera readback succeeds but the computer cannot see the file: report the
    camera output and host OS/card-reader details; do not repeat write tests.
