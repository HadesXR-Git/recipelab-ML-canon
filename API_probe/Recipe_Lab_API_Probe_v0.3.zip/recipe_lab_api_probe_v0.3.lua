-- Recipe Lab API Probe v0.3 - filesystem write/readback verification
-- Target: Canon EOS 700D, firmware 1.1.5, ML Nightly.2018Jul03.700D115
-- This probe does NOT change camera or Picture Style settings.
-- It creates one short 8.3 test file in the existing ML/LOGS directory,
-- closes it, reopens it, reads it back, and checks the directory listing.

local OUTPUT_DIR = "ML/LOGS"
local OUTPUT_NAME = "RLBPROBE.TXT" -- strict 8.3 filename
local TEST_CONTENT = "RECIPE_LAB_WRITE_READBACK_V03\r\n"

local function safe_tostring(value)
    local ok, result = pcall(tostring, value)
    if ok then return result end
    return "<tostring error>"
end

local function normalize_path(path)
    return safe_tostring(path or ""):gsub("\\", "/"):gsub("/+$", "")
end

local function show_result(label, value)
    print(label .. ": " .. safe_tostring(value))
end

local function find_name(dir, expected_name)
    local ok, list_or_error = pcall(function()
        return dir:files()
    end)
    if not ok then
        return false, "files() raised: " .. safe_tostring(list_or_error), nil
    end
    if type(list_or_error) ~= "table" then
        return false, "files() did not return a table (" .. type(list_or_error) .. ")", nil
    end

    local count = #list_or_error
    local expected = string.upper(expected_name)
    for _, item in ipairs(list_or_error) do
        local name = safe_tostring(item)
        if string.upper(name) == expected then
            return true, "found exact filename", count
        end
    end
    return false, "not present in files() listing", count
end

local function run_probe()
    menu.close()
    console.clear()
    console.show()

    print("RECIPE LAB - FILESYSTEM PROBE v0.3")
    print("Read/write test only; no camera settings changed.")
    print("")
    print("1. OPEN KNOWN DIRECTORY")

    local dir_ok, dir = pcall(function()
        return dryos.directory(OUTPUT_DIR)
    end)
    if not dir_ok then
        show_result("Directory open", "FAILED: " .. safe_tostring(dir))
        print("Cannot continue. No file was written.")
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end
    if dir == nil then
        print("Directory open: FAILED (returned nil)")
        print("Cannot continue. No file was written.")
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end
    show_result("Directory exists", dir.exists)
    show_result("Directory path", dir.path)
    if dir.exists ~= true or dir.path == nil then
        print("Directory is unavailable. No file was written.")
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end

    local dir_path = normalize_path(dir.path)
    local output_path = dir_path .. "/" .. OUTPUT_NAME
    show_result("Test file path", output_path)
    print("")
    print("2. CREATE, WRITE, FLUSH, CLOSE")

    local open_ok, file_or_error = pcall(io.open, output_path, "w")
    if not open_ok or file_or_error == nil then
        show_result("io.open", "FAILED: " .. safe_tostring(file_or_error))
        print("No readback attempted.")
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end
    print("io.open: returned a file handle")

    local file = file_or_error
    local write_ok, write_result, write_error = pcall(function()
        return file:write(TEST_CONTENT)
    end)
    if write_ok and write_result ~= nil then
        print("write(): returned success value")
    elseif write_ok then
        show_result("write()", "returned nil: " .. safe_tostring(write_error))
    else
        show_result("write()", "raised: " .. safe_tostring(write_result))
    end

    local flush_ok, flush_result, flush_error = pcall(function()
        return file:flush()
    end)
    if flush_ok and flush_result ~= nil then
        show_result("flush()", flush_result)
    elseif flush_ok then
        show_result("flush()", "returned nil: " .. safe_tostring(flush_error))
    else
        show_result("flush()", "raised: " .. safe_tostring(flush_result))
    end

    local close_ok, close_result, close_error = pcall(function()
        return file:close()
    end)
    if close_ok and close_result ~= nil then
        show_result("close()", close_result)
    elseif close_ok then
        show_result("close()", "returned nil: " .. safe_tostring(close_error))
    else
        show_result("close()", "raised: " .. safe_tostring(close_result))
    end

    print("")
    print("3. VERIFY DIRECTORY LISTING")
    local fresh_ok, fresh_dir = pcall(function()
        return dryos.directory(OUTPUT_DIR)
    end)
    if fresh_ok and fresh_dir ~= nil and fresh_dir.exists == true then
        local found, detail, count = find_name(fresh_dir, OUTPUT_NAME)
        show_result("Directory files() count", count)
        show_result("File visible in directory", found)
        show_result("Directory check", detail)
    else
        show_result("Directory re-open", "FAILED: " .. safe_tostring(fresh_dir))
    end

    print("")
    print("4. REOPEN AND READ BACK")
    local read_open_ok, read_file_or_error = pcall(io.open, output_path, "rb")
    if not read_open_ok or read_file_or_error == nil then
        show_result("Read reopen", "FAILED: " .. safe_tostring(read_file_or_error))
    else
        local read_file = read_file_or_error
        local read_ok, contents_or_error = pcall(function()
            return read_file:read("*all")
        end)
        if read_ok then
            local contents = safe_tostring(contents_or_error)
            show_result("Read bytes", #contents)
            show_result("Readback matches test marker", contents == TEST_CONTENT)
            if contents ~= TEST_CONTENT then
                show_result("Readback contents", string.format("%q", contents))
            end
        else
            show_result("Read", "FAILED: " .. safe_tostring(contents_or_error))
        end

        local seek_ok, size_or_error = pcall(function()
            return read_file:seek("end", 0)
        end)
        if seek_ok then
            show_result("File size from seek", size_or_error)
        else
            show_result("File size", "unavailable: " .. safe_tostring(size_or_error))
        end

        local read_close_ok, read_close_result = pcall(function()
            return read_file:close()
        end)
        show_result("Read handle close", read_close_ok and safe_tostring(read_close_result) or ("raised: " .. safe_tostring(read_close_result)))
    end

    print("")
    print("TEST FILE LEFT IN PLACE:")
    print(output_path)
    print("After shutting the camera down, check SD:/ML/LOGS/RLBPROBE.TXT")
    print("This probe does not import or modify any Picture Style.")
    print("Press any key to return.")
    key.wait()
    console.hide()
end

local probe_menu = menu.new {
    parent = "Scripts",
    name = "Recipe Lab - FS Probe v0.3",
    help = "Creates a short test file in ML/LOGS and verifies it by listing and readback.",
    submenu = {
        {
            name = "Run filesystem write/readback test",
            help = "Writes RLBPROBE.TXT to ML/LOGS, reopens it, and verifies its contents.",
            select = function(this)
                task.create(run_probe)
            end
        },
        {
            name = "Safety: no camera changes",
            help = "Only creates one small text file. No Picture Style properties are changed."
        }
    }
}
