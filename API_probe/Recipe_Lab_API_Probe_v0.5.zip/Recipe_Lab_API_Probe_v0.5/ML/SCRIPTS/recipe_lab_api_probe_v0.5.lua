-- Recipe Lab API Probe v0.5
-- Target: Canon EOS 700D / firmware 1.1.5 / Crop Mood ML Nightly.2018Jul03.700D115
-- READ-ONLY with respect to camera properties and Picture Style slots.
-- Writes a diagnostic report to the already-tested ML/LOGS directory and
-- verifies it by reopening the file and checking the report sentinel.

local LOG_DIR = "ML/LOGS"
local LOG_NAME = "RLAPI04.TXT" -- 7.3 name; compatible with FAT 8.3 naming
local REPORT_SENTINEL = "RECIPE_LAB_API_PROBE_V05_END"

local function safe_tostring(value)
    local ok, result = pcall(tostring, value)
    if ok then return result end
    return "<tostring error>"
end

local function normalize_path(path)
    local s = safe_tostring(path or "")
    s = s:gsub("\\", "/")
    s = s:gsub("/+$", "")
    return s
end

local function safe_get(label, getter, lines)
    local ok, value = pcall(getter)
    if ok then
        lines[#lines + 1] = label .. " = " .. safe_tostring(value) .. " [" .. type(value) .. "]"
    else
        lines[#lines + 1] = label .. " = <ERROR: " .. safe_tostring(value) .. ">"
    end
end

local function safe_type(label, getter, lines)
    local ok, value = pcall(getter)
    if ok then
        lines[#lines + 1] = label .. " type = " .. type(value)
    else
        lines[#lines + 1] = label .. " type = <ERROR: " .. safe_tostring(value) .. ">"
    end
end

local function describe_meta(label, object, lines)
    local ok, mt = pcall(getmetatable, object)
    if not ok then
        lines[#lines + 1] = label .. " metatable = <ERROR: " .. safe_tostring(mt) .. ">"
        return
    end
    lines[#lines + 1] = label .. " metatable type = " .. type(mt)
    if type(mt) == "table" then
        lines[#lines + 1] = label .. " metatable.__index type = " .. type(mt.__index)
        lines[#lines + 1] = label .. " metatable.__newindex type = " .. type(mt.__newindex)
        lines[#lines + 1] = label .. " metatable.__pairs type = " .. type(mt.__pairs)
    end
end

local function property_info(name, lines)
    local ok, prop = pcall(function()
        return property[name]
    end)
    if not ok then
        lines[#lines + 1] = "property." .. name .. " = <ERROR: " .. safe_tostring(prop) .. ">"
        return
    end
    lines[#lines + 1] = "property." .. name .. " type = " .. type(prop)
    if type(prop) == "table" then
        local id_ok, id = pcall(function() return prop._id end)
        if id_ok then
            lines[#lines + 1] = "property." .. name .. "._id = " .. safe_tostring(id) .. " [" .. type(id) .. "]"
        else
            lines[#lines + 1] = "property." .. name .. "._id = <ERROR: " .. safe_tostring(id) .. ">"
        end
        local handler_ok, handler = pcall(function() return prop.handler end)
        if handler_ok then
            lines[#lines + 1] = "property." .. name .. ".handler type = " .. type(handler)
        else
            lines[#lines + 1] = "property." .. name .. ".handler = <ERROR: " .. safe_tostring(handler) .. ">"
        end
    end
end

local function build_report()
    local lines = {}
    local function add(s) lines[#lines + 1] = s end

    add("RECIPE LAB - API PROBE v0.5")
    add("Target: Canon EOS 700D / firmware 1.1.5")
    add("Build: ML Nightly.2018Jul03.700D115 (Crop Mood)")
    add("Mode: READ-ONLY; no property handlers or setters are used")
    add("")

    add("[CAMERA]")
    safe_get("camera.model", function() return camera.model end, lines)
    safe_get("camera.model_short", function() return camera.model_short end, lines)
    safe_get("camera.firmware", function() return camera.firmware end, lines)
    safe_get("camera.mode", function() return camera.mode end, lines)
    add("")

    add("[LENS API - DIRECT READS]")
    safe_get("lens.name", function() return lens.name end, lines)
    safe_get("lens.picstyle", function() return lens.picstyle end, lines)
    safe_get("lens.raw_picstyle", function() return lens.raw_picstyle end, lines)
    safe_get("lens.contrast", function() return lens.contrast end, lines)
    safe_get("lens.sharpness", function() return lens.sharpness end, lines)
    safe_get("lens.saturation", function() return lens.saturation end, lines)
    safe_get("lens.color_tone", function() return lens.color_tone end, lines)
    add("")

    add("[PICTURE-STYLE-RELATED PROPERTY OBJECTS]")
    property_info("PICTURE_STYLE", lines)
    property_info("PC_FLAVOR1_PARAM", lines)
    property_info("PC_FLAVOR2_PARAM", lines)
    property_info("PC_FLAVOR3_PARAM", lines)
    property_info("PICSTYLE", lines)
    add("")

    add("[RELEVANT API MEMBER TYPES - NO CALLS]")
    safe_type("type(dryos.directory)", function() return dryos.directory end, lines)
    safe_type("type(dryos.remove)", function() return dryos.remove end, lines)
    safe_type("type(dryos.rename)", function() return dryos.rename end, lines)
    safe_type("type(dryos.call)", function() return dryos.call end, lines)
    safe_type("type(property.PICTURE_STYLE.request_change)", function() return property.PICTURE_STYLE.request_change end, lines)
    safe_get("event.custom_picture_taking", function() return event.custom_picture_taking end, lines)
    add("")

    add("[METATABLE INFORMATION]")
    describe_meta("lens", lens, lines)
    describe_meta("property", property, lines)
    describe_meta("event", event, lines)
    describe_meta("dryos", dryos, lines)
    add("")

    add("[NOTES]")
    add("No table enumeration is used: these API objects may be metatable-backed.")
    add("No property handler is registered. No property request_change is called.")
    add("No dryos.call or undocumented firmware function is invoked.")
    add(REPORT_SENTINEL)

    return table.concat(lines, "\r\n") .. "\r\n"
end

local function run_probe()
    menu.close()
    console.clear()
    console.show()

    print("RECIPE LAB - API PROBE v0.5")
    print("Read-only API checks; writing report to ML/LOGS.")
    print("")

    local dir_ok, dir = pcall(function() return dryos.directory(LOG_DIR) end)
    if not dir_ok or dir == nil or dir.exists ~= true or dir.path == nil then
        local reason = "unknown directory error"
        if not dir_ok then
            reason = safe_tostring(dir)
        elseif dir == nil then
            reason = "dryos.directory returned nil"
        elseif dir.exists ~= true then
            reason = "directory exists=" .. safe_tostring(dir.exists)
        elseif dir.path == nil then
            reason = "directory path is nil"
        end
        print("LOG SETUP: FAILED")
        print("Directory: " .. safe_tostring(LOG_DIR))
        print("Reason: " .. reason)
        print("No report written. Check that ML/LOGS exists.")
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end

    local base = normalize_path(dir.path)
    local output_path = base .. "/" .. LOG_NAME
    print("Output: " .. output_path)

    local report_ok, report = pcall(build_report)
    if not report_ok then
        print("REPORT BUILD: FAILED")
        print(safe_tostring(report))
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end

    local open_ok, file = pcall(io.open, output_path, "w")
    if not open_ok or file == nil then
        print("LOG OPEN: FAILED")
        print(safe_tostring(file))
        print("Press any key to return.")
        key.wait()
        console.hide()
        return
    end

    local write_ok, write_result, write_err = pcall(function()
        return file:write(report)
    end)
    local flush_ok, flush_result, flush_err = pcall(function()
        return file:flush()
    end)
    local close_ok, close_result, close_err = pcall(function()
        return file:close()
    end)

    print("WRITE CALL: " .. safe_tostring(write_ok and write_result ~= nil))
    if not write_ok then print("WRITE ERROR: " .. safe_tostring(write_result)) end
    if write_ok and write_result == nil then print("WRITE DETAIL: " .. safe_tostring(write_err)) end
    print("FLUSH CALL: " .. safe_tostring(flush_ok))
    if not flush_ok then print("FLUSH ERROR: " .. safe_tostring(flush_result)) end
    if flush_ok and flush_result == nil and flush_err ~= nil then print("FLUSH DETAIL: " .. safe_tostring(flush_err)) end
    print("CLOSE CALL: " .. safe_tostring(close_ok))
    if not close_ok then print("CLOSE ERROR: " .. safe_tostring(close_result)) end
    if close_ok and close_result == nil and close_err ~= nil then print("CLOSE DETAIL: " .. safe_tostring(close_err)) end

    local read_open_ok, read_file = pcall(io.open, output_path, "rb")
    if not read_open_ok or read_file == nil then
        print("READBACK OPEN: FAILED")
        print("Reason: " .. safe_tostring(read_file))
    else
        local read_ok, contents = pcall(function() return read_file:read("*all") end)
        local read_close_ok, read_close_err = pcall(function() return read_file:close() end)
        if read_ok and type(contents) == "string" then
            local verified = string.find(contents, REPORT_SENTINEL, 1, true) ~= nil
            print("READBACK: " .. (verified and "VERIFIED" or "FAILED"))
            print("Bytes: " .. tostring(#contents))
            print("Expected bytes: " .. tostring(#report))
            print("Exact report match: " .. tostring(contents == report))
            print("Sentinel present: " .. tostring(verified))
        else
            print("READBACK: FAILED")
            print("Reason: " .. safe_tostring(contents))
        end
        print("READ HANDLE CLOSE: " .. safe_tostring(read_close_ok))
        if not read_close_ok then print("READ CLOSE ERROR: " .. safe_tostring(read_close_err)) end
    end

    print("")
    print("LOG FILE: " .. output_path)
    print("Check SD:/ML/LOGS/" .. LOG_NAME)
    print("No Picture Style settings were changed.")
    print("Press any key to return.")
    key.wait()
    console.hide()
end

local probe_menu = menu.new {
    parent = "Scripts",
    name = "Recipe Lab - API Probe v0.5",
    help = "Read-only API inventory; verified report saved in ML/LOGS.",
    submenu = {
        {
            name = "Run read-only API probe",
            help = "Reads known API fields and saves RLAPI04.TXT in ML/LOGS.",
            select = function(this)
                task.create(run_probe)
            end
        },
        {
            name = "Safety: no camera changes",
            help = "No setters, property handlers, or firmware calls are used."
        }
    }
}

print("Recipe Lab API Probe v0.5 loaded. Open Scripts > Recipe Lab - API Probe v0.5.")
