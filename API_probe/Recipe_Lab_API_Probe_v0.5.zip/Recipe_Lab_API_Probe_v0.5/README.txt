RECIPE LAB - API PROBE v0.5
===========================

Target
------
Canon EOS 700D / firmware 1.1.5
Magic Lantern Nightly.2018Jul03.700D115 (Crop Mood)

Purpose
-------
Collect a read-only inventory of selected Picture-Style-related Lua API
objects and save the report in the already-tested ML/LOGS directory.

What changed from v0.4
----------------------
- Output filename changed from RLB_API04.LOG to RLAPI04.TXT.
- RLAPI04.TXT uses a 7-character base name and a 3-character extension,
  fitting the traditional FAT 8.3 filename format.
- Uses the same ML/LOGS directory that successfully stored RLBPROBE.TXT.
- Keeps write, flush, close, reopen, readback, sentinel and exact-content checks.
- No camera settings or Picture Style slots are modified.

Output
------
SD:/ML/LOGS/RLAPI04.TXT

Install and run
---------------
1. Copy recipe_lab_api_probe_v0.5.lua into ML/SCRIPTS/.
2. Boot the camera and open Magic Lantern > Scripts.
3. Run "Recipe Lab - API Probe v0.5".
4. Select "Run read-only API probe".
5. Confirm READBACK: VERIFIED on the camera.
6. Shut the camera down normally, remove the card and upload:
   ML/LOGS/RLAPI04.TXT

Safety
------
- Does not write Picture Style properties.
- Does not register property handlers.
- Does not invoke dryos.call() or undocumented firmware functions.
- Writes only one diagnostic text file in ML/LOGS.
- Re-running overwrites only RLAPI04.TXT.

Interpretation
--------------
This is a diagnostic inventory, not a PF2/PF3 loader. No profile
registration or camera-setting changes are attempted.
