RECIPE LAB BROWSER - MAGIC LANTERN / CANON EOS 700D
Version 0.1 - READ-ONLY PROTOTYPE

WHAT THIS DOES
- Scans the SD-card root folder PFProfiles/.
- Finds .PF2 and .PF3 files (extension matching is case-insensitive).
- Also scans subfolders, up to four directory levels below PFProfiles/.
- Shows separate PF2 and PF3 lists inside a Magic Lantern menu.
- Lets you inspect a selected file's full path, extension, and file size.
- Does not import, register, or apply any Picture Style.
- Does not write to profile files or camera settings.

INSTALLATION
1. Back up your SD card before changing anything.
2. Copy recipe_lab.lua into the existing folder:
       /ML/scripts/recipe_lab.lua
3. Keep your recipe files in the SD-card root folder:
       /PFProfiles/
   Example:
       /PFProfiles/Fuji Pro 160C.pf2
       /PFProfiles/Polaroid_Polachrome_sixaxis.pf3
4. Safely eject the card and put it back in the EOS 700D.
5. Start the camera and open the Magic Lantern menu.
6. Open Scripts and run recipe_lab.lua once.
7. A new "Recipe Lab" entry should appear under Scripts.
8. Open Recipe Lab, then PF2 Profiles or PF3 Profiles.

USAGE
- Select "Show full scan report" to view the full names and paths in the console.
- Select a profile to inspect it. This only opens it read-only to check that it
  can be opened and to read its size. It does not load the picture style.
- The menu is built when the script is loaded. If you add/remove/rename files,
  restart the camera to rebuild the list.

NOTES
- The script uses dryos.directory(...):files() and :children(), APIs already
  used by the file-dialog script included with the supplied Magic Lantern build.
- The scanner stops after 250 matching profiles and does not descend beyond
  four folder levels beneath PFProfiles/.
- If the folder is missing or inaccessible, check the scan report warnings.
- This is an untested first prototype. It has not yet been run on the physical
  EOS 700D. Please test the browser only; no profile loading is implemented.

NEXT MILESTONE
Once directory enumeration and menu display are confirmed on the camera,
we can investigate the Canon PF2/PF3 registration mechanism separately.
