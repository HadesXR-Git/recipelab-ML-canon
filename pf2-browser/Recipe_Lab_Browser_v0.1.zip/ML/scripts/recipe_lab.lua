-- Recipe Lab Browser for Magic Lantern (Canon EOS 700D / Nightly 2018Jul03)
-- Version: 0.1 - READ-ONLY PROFILE BROWSER
--
-- Scans the SD-card root folder PFProfiles/ for .PF2 and .PF3 files.
-- It lists matching files in a Magic Lantern submenu and can show file
-- details. This version DOES NOT import, register, or apply Picture Styles.
--
-- Install as: ML/SCRIPTS/recipe_lab.lua
-- Profiles:   PFProfiles/<your profile files>

local PROFILE_ROOT = "PFProfiles/"
local MAX_DEPTH = 4
local MAX_PROFILES = 250

local profiles = {}
local scan_warnings = {}
local scan_truncated = false

local function basename(path)
    return string.match(path, "([^/]+)$") or path
end

local function relative_path(path)
    local rel = string.gsub(path, "^PFProfiles/", "")
    return rel
end

local function profile_format(path)
    local name = basename(path)
    local extension = string.match(name, "%.([^%.]+)$")
    if extension == nil then
        return nil
    end

    extension = string.lower(extension)
    if extension == "pf2" then
        return "PF2"
    elseif extension == "pf3" then
        return "PF3"
    end

    return nil
end

local function add_warning(message)
    if #scan_warnings < 20 then
        scan_warnings[#scan_warnings + 1] = message
    end
end

local function walk_directory(path, depth)
    if #profiles >= MAX_PROFILES then
        scan_truncated = true
        return
    end

    local dir_ok, dir = pcall(function()
        return dryos.directory(path)
    end)

    if not dir_ok or dir == nil then
        add_warning("Cannot open folder: " .. path .. " (" .. tostring(dir) .. ")")
        return
    end

    -- The directory API returns full paths for files. This is also how the
    -- file-dialog code bundled with this Magic Lantern build uses it.
    local files_ok, files = pcall(function()
        return dir:files()
    end)

    if files_ok and type(files) == "table" then
        for _, file_path in ipairs(files) do
            local format = profile_format(file_path)
            if format ~= nil then
                local key = string.lower(file_path)
                local already_added = false

                for _, existing in ipairs(profiles) do
                    if existing.key == key then
                        already_added = true
                        break
                    end
                end

                if not already_added then
                    profiles[#profiles + 1] = {
                        path = file_path,
                        relative = relative_path(file_path),
                        name = basename(file_path),
                        format = format,
                        key = key
                    }
                end

                if #profiles >= MAX_PROFILES then
                    scan_truncated = true
                    break
                end
            end
        end
    else
        add_warning("Could not list files in " .. path .. ": " .. tostring(files))
    end

    if depth < MAX_DEPTH and #profiles < MAX_PROFILES then
        local children_ok, children = pcall(function()
            return dir:children()
        end)

        if children_ok and type(children) == "table" then
            table.sort(children, function(a, b)
                return tostring(a.path) < tostring(b.path)
            end)

            for _, child in ipairs(children) do
                if child.path ~= nil then
                    walk_directory(child.path, depth + 1)
                end
                if #profiles >= MAX_PROFILES then
                    scan_truncated = true
                    break
                end
            end
        else
            add_warning("Could not list subfolders in " .. path .. ": " .. tostring(children))
        end
    elseif depth >= MAX_DEPTH then
        -- Nested folders beyond this depth are intentionally ignored.
    end
end

local function scan_profiles()
    profiles = {}
    scan_warnings = {}
    scan_truncated = false

    walk_directory(PROFILE_ROOT, 0)

    table.sort(profiles, function(a, b)
        local a_lower = string.lower(a.relative)
        local b_lower = string.lower(b.relative)
        if a_lower == b_lower then
            return a.relative < b.relative
        end
        return a_lower < b_lower
    end)
end

local function run_console(title, callback)
    task.create(function()
        menu.close()
        console.show()
        console.clear()

        print("RECIPE LAB - READ ONLY")
        print(title)
        print("--------------------------------")

        local ok, err = pcall(callback)
        if not ok then
            print("Script error: " .. tostring(err))
        end

        print("")
        print("No camera Picture Style settings were changed.")
        print("Press any key to return.")
        key.wait()
        console.hide()
    end)
end

local function show_report()
    run_console("SD-card scan report", function()
        local pf2_count = 0
        local pf3_count = 0

        for _, profile in ipairs(profiles) do
            if profile.format == "PF2" then
                pf2_count = pf2_count + 1
            elseif profile.format == "PF3" then
                pf3_count = pf3_count + 1
            end
        end

        print("Folder: " .. PROFILE_ROOT)
        print("PF2 files: " .. tostring(pf2_count))
        print("PF3 files: " .. tostring(pf3_count))
        print("Total: " .. tostring(#profiles))
        print("")

        if #profiles == 0 then
            print("No .PF2 or .PF3 files were found.")
            print("Check that PFProfiles is at the SD-card root.")
        else
            for index, profile in ipairs(profiles) do
                print(string.format("%03d  [%s]  %s", index, profile.format, profile.relative))
            end
        end

        if scan_truncated then
            print("")
            print("NOTE: Listing stopped at the safety limit of " .. tostring(MAX_PROFILES) .. " profiles.")
        end

        if #scan_warnings > 0 then
            print("")
            print("Scan warnings:")
            for _, warning in ipairs(scan_warnings) do
                print("- " .. warning)
            end
        end
    end)
end

local function show_profile(profile)
    run_console("Profile details", function()
        print("Name: " .. profile.name)
        print("Relative path: " .. profile.relative)
        print("Full path: " .. profile.path)
        print("Detected extension: " .. profile.format)

        local file, err = io.open(profile.path, "rb")
        if file ~= nil then
            local size = file:seek("end", 0)
            file:close()
            if size ~= nil then
                print("File size: " .. tostring(size) .. " bytes")
            else
                print("File size: unavailable")
            end
            print("Read test: file opened successfully")
        else
            print("Read test: could not open file")
            print("Reason: " .. tostring(err))
        end

        print("")
        print("This is a browser-only test.")
        print("The profile has NOT been loaded or applied.")
    end)
end

local function make_profile_item(profile)
    return {
        name = profile.relative,
        help = "Select to inspect this file. No profile is applied.",
        select = function(this)
            show_profile(profile)
        end
    }
end

local function make_format_submenu(format, label)
    local items = {}

    for _, profile in ipairs(profiles) do
        if profile.format == format then
            items[#items + 1] = make_profile_item(profile)
        end
    end

    local profile_count = #items
    if profile_count == 0 then
        items[1] = {
            name = "No " .. format .. " files found",
            help = "Place matching files in " .. PROFILE_ROOT
        }
    end

    return {
        name = label .. " (" .. tostring(profile_count) .. ")",
        help = "Browse " .. format .. " profiles. Selecting an item only shows file details.",
        submenu = items
    }
end

-- Scan once when the script is loaded. Restart/reload the script after
-- changing the contents of PFProfiles so the menu can be rebuilt.
scan_profiles()

local menu_items = {
    {
        name = "Show full scan report",
        help = "Print every detected profile name and path.",
        select = function(this)
            show_report()
        end
    },
    make_format_submenu("PF2", "PF2 Profiles"),
    make_format_submenu("PF3", "PF3 Profiles"),
    {
        name = "Browser only - no importing",
        help = "This version does not register or apply Picture Styles."
    }
}

local recipe_lab_menu = menu.new {
    parent = "Scripts",
    name = "Recipe Lab",
    help = "Read-only browser for PF2/PF3 files in PFProfiles/.",
    submenu = menu_items
}

