-- Recipe Lab Browser for Magic Lantern (Canon EOS 700D / Nightly 2018Jul03)
-- Version: 0.3 - READ-ONLY PF2/PF3 BROWSER
--
-- Scans the root-level PFProfiles folder on the SD card.
--
-- Important v0.3 change:
--   Do NOT try dryos.directory("PFProfiles") directly. Instead, open the
--   known-good ML/SCRIPTS directory, walk up via .parent twice to the card
--   root, then find PFProfiles among the root directory's :children().
--   This follows the same Directory objects used by the bundled editor.lua.
--
-- Install as: ML/SCRIPTS/recipe_lab.lua
-- Profiles:   PFProfiles/<profiles and optional subfolders>
--
-- This script is READ-ONLY. It does not register or apply Picture Styles.

local PROFILE_FOLDER_NAME = "PFProfiles"
local SCRIPT_ANCHOR_CANDIDATES = { "ML/SCRIPTS", "ML/scripts" }
local MAX_DEPTH = 4
local MAX_PROFILES = 250
local MAX_ROOT_NAMES_IN_REPORT = 40

local profiles = {}
local scan_warnings = {}
local scan_truncated = false
local root_info = {}
local card_root_dir = nil
local profile_root_dir = nil

local function normalize_path(path)
    return tostring(path or ""):gsub("\\", "/")
end

local function basename(path)
    local clean = normalize_path(path):gsub("/+$", "")
    return string.match(clean, "([^/]+)$") or clean
end

local function add_trailing_slash(path)
    path = normalize_path(path)
    if path ~= "" and string.sub(path, -1) ~= "/" then
        path = path .. "/"
    end
    return path
end

local function join_path(dir_path, file_name)
    local name = normalize_path(file_name)
    if string.sub(name, 1, 1) == "/" or string.match(name, "^[A-Za-z]:/") then
        return name
    end
    return add_trailing_slash(dir_path) .. name
end

local function profile_format(file_name)
    local extension = string.match(basename(file_name), "%.([^%.]+)$")
    if extension == nil then return nil end

    extension = string.lower(extension)
    if extension == "pf2" then return "PF2" end
    if extension == "pf3" then return "PF3" end
    return nil
end

local function add_warning(message)
    if #scan_warnings < 40 then
        scan_warnings[#scan_warnings + 1] = tostring(message)
    end
end

local function safe_directory(path)
    local ok, result = pcall(function()
        return dryos.directory(path)
    end)
    if not ok then
        return nil, "dryos.directory(" .. tostring(path) .. ") raised: " .. tostring(result)
    end
    if result == nil then
        return nil, "dryos.directory(" .. tostring(path) .. ") returned nil"
    end
    if result.exists ~= true then
        return nil, "Directory object for " .. tostring(path) .. " reports exists=" .. tostring(result.exists)
    end
    return result, nil
end

local function safe_children(dir, label)
    local ok, result = pcall(function()
        return dir:children()
    end)
    if not ok then
        add_warning("children() failed for " .. tostring(label) .. ": " .. tostring(result))
        return nil
    end
    if type(result) ~= "table" then
        add_warning("children() returned " .. type(result) .. " for " .. tostring(label))
        return nil
    end
    return result
end

local function safe_files(dir, label)
    local ok, result = pcall(function()
        return dir:files()
    end)
    if not ok then
        add_warning("files() failed for " .. tostring(label) .. ": " .. tostring(result))
        return nil
    end
    if type(result) ~= "table" then
        add_warning("files() returned " .. type(result) .. " for " .. tostring(label))
        return nil
    end
    return result
end

local function add_profile(full_path, relative_path, file_name, format)
    local key = string.lower(normalize_path(full_path))
    for _, existing in ipairs(profiles) do
        if existing.key == key then return end
    end

    profiles[#profiles + 1] = {
        path = full_path,
        relative = relative_path,
        name = basename(file_name),
        format = format,
        key = key
    }
end

-- Resolve the card root using the parent chain of a known-good ML folder.
-- editor.lua in this exact build initializes its file dialog with
-- dryos.directory("ML/SCRIPTS") and navigates folders through .parent.
local function resolve_profile_folder()
    local anchor = nil
    local anchor_path = nil
    local anchor_errors = {}

    for _, candidate in ipairs(SCRIPT_ANCHOR_CANDIDATES) do
        local result, err = safe_directory(candidate)
        if result ~= nil then
            anchor = result
            anchor_path = candidate
            break
        end
        anchor_errors[#anchor_errors + 1] = err
    end

    if anchor == nil then
        add_warning("Could not open the known ML/SCRIPTS anchor. " .. table.concat(anchor_errors, " | "))
        return nil
    end

    root_info.anchor_path = anchor_path
    root_info.anchor_resolved_path = tostring(anchor.path or "(no path property)")

    local ml_dir = anchor.parent
    if ml_dir == nil then
        add_warning("The ML/SCRIPTS directory has no parent object; cannot derive card root.")
        return nil
    end

    local root_dir = ml_dir.parent
    if root_dir == nil then
        add_warning("The ML directory has no parent object; cannot derive card root.")
        return nil
    end

    if root_dir.exists ~= true then
        add_warning("Derived card-root object reports exists=" .. tostring(root_dir.exists))
        return nil
    end

    card_root_dir = root_dir
    root_info.card_root_path = tostring(root_dir.path or "(no path property)")

    local root_children = safe_children(root_dir, "SD-card root")
    if root_children == nil then return nil end

    root_info.root_directory_count = #root_children
    root_info.root_directory_names = {}
    table.sort(root_children, function(a, b)
        return string.lower(basename(a and a.path or "")) < string.lower(basename(b and b.path or ""))
    end)

    for _, child in ipairs(root_children) do
        if child ~= nil and child.path ~= nil then
            local child_name = basename(child.path)
            if #root_info.root_directory_names < MAX_ROOT_NAMES_IN_REPORT then
                root_info.root_directory_names[#root_info.root_directory_names + 1] = child_name
            end
            if string.lower(child_name) == string.lower(PROFILE_FOLDER_NAME) then
                profile_root_dir = child
            end
        else
            add_warning("A card-root child directory had no path property.")
        end
    end

    if profile_root_dir == nil then
        add_warning("Could not find '" .. PROFILE_FOLDER_NAME .. "' among the SD-card root directories.")
        return nil
    end

    root_info.profile_folder_path = tostring(profile_root_dir.path or "(no path property)")
    if profile_root_dir.exists ~= true then
        add_warning("Found PFProfiles entry, but it reports exists=" .. tostring(profile_root_dir.exists))
        return nil
    end

    return profile_root_dir
end

local function walk_directory(dir, depth, relative_dir)
    if #profiles >= MAX_PROFILES then
        scan_truncated = true
        return
    end

    if dir == nil or dir.exists ~= true then
        add_warning("A directory object was nil or not present while scanning " .. tostring(relative_dir))
        return
    end

    local dir_path = tostring(dir.path or "")
    if dir_path == "" then
        add_warning("Directory has no path property while scanning " .. tostring(relative_dir))
        return
    end

    local file_entries = safe_files(dir, dir_path)
    if file_entries ~= nil then
        if depth == 0 then root_info.profile_file_count = #file_entries end

        for _, file_entry in ipairs(file_entries) do
            local file_name = tostring(file_entry)
            local format = profile_format(file_name)
            if format ~= nil then
                local full_path = join_path(dir_path, file_name)
                local relative = relative_dir .. basename(file_name)
                add_profile(full_path, relative, file_name, format)
                if #profiles >= MAX_PROFILES then
                    scan_truncated = true
                    break
                end
            end
        end
    end

    if depth < MAX_DEPTH and #profiles < MAX_PROFILES then
        local children = safe_children(dir, dir_path)
        if children ~= nil then
            table.sort(children, function(a, b)
                return string.lower(basename(a and a.path or "")) < string.lower(basename(b and b.path or ""))
            end)

            for _, child in ipairs(children) do
                if child ~= nil and child.path ~= nil then
                    local child_name = basename(child.path)
                    walk_directory(child, depth + 1, relative_dir .. child_name .. "/")
                else
                    add_warning("A subdirectory entry had no path under " .. dir_path)
                end

                if #profiles >= MAX_PROFILES then
                    scan_truncated = true
                    break
                end
            end
        end
    end
end

local function scan_profiles()
    profiles = {}
    scan_warnings = {}
    scan_truncated = false
    card_root_dir = nil
    profile_root_dir = nil
    root_info = {
        anchor_path = "(not opened)",
        anchor_resolved_path = "(not opened)",
        card_root_path = "(not resolved)",
        root_directory_count = 0,
        root_directory_names = {},
        profile_folder_path = "(not found)",
        profile_file_count = 0
    }

    local target = resolve_profile_folder()
    if target ~= nil then
        walk_directory(target, 0, "")
    end

    table.sort(profiles, function(a, b)
        local a_lower = string.lower(a.relative)
        local b_lower = string.lower(b.relative)
        if a_lower == b_lower then return a.relative < b.relative end
        return a_lower < b_lower
    end)
end

local function run_console(title, callback)
    task.create(function()
        menu.close()
        console.show()
        console.clear()

        print("RECIPE LAB - READ ONLY")
        print(title)
        print("--------------------------------")

        local ok, err = pcall(callback)
        if not ok then
            print("Script error: " .. tostring(err))
        end

        print("")
        print("No camera Picture Style settings were changed.")
        print("Press any key to return.")
        key.wait()
        console.hide()
    end)
end

local function show_report()
    run_console("SD-card scan report", function()
        local pf2_count, pf3_count = 0, 0
        for _, profile in ipairs(profiles) do
            if profile.format == "PF2" then pf2_count = pf2_count + 1 end
            if profile.format == "PF3" then pf3_count = pf3_count + 1 end
        end

        print("Anchor opened: " .. tostring(root_info.anchor_path))
        print("Anchor path: " .. tostring(root_info.anchor_resolved_path))
        print("Card root path: " .. tostring(root_info.card_root_path))
        print("Root directories: " .. tostring(root_info.root_directory_count))
        print("PFProfiles path: " .. tostring(root_info.profile_folder_path))
        print("Files inside PFProfiles: " .. tostring(root_info.profile_file_count))
        print("")
        print("PF2 files found: " .. tostring(pf2_count))
        print("PF3 files found: " .. tostring(pf3_count))
        print("Total profiles: " .. tostring(#profiles))

        if #root_info.root_directory_names > 0 then
            print("")
            print("Directories at card root:")
            for _, name in ipairs(root_info.root_directory_names) do
                print("- " .. tostring(name))
            end
            if root_info.root_directory_count > #root_info.root_directory_names then
                print("(list limited to " .. tostring(MAX_ROOT_NAMES_IN_REPORT) .. ")")
            end
        end

        if #profiles > 0 then
            print("")
            print("Detected profiles:")
            for index, profile in ipairs(profiles) do
                print(string.format("%03d [%s] %s", index, profile.format, profile.relative))
            end
        end

        if scan_truncated then
            print("")
            print("Listing stopped at safety limit: " .. tostring(MAX_PROFILES))
        end

        if #scan_warnings > 0 then
            print("")
            print("Scan diagnostics:")
            for _, warning in ipairs(scan_warnings) do
                print("- " .. warning)
            end
        end

        if #profiles == 0 and #scan_warnings == 0 then
            print("")
            print("PFProfiles was opened, but no PF2/PF3 files were found.")
        end
    end)
end

local function show_profile(profile)
    run_console("Profile details", function()
        print("Name: " .. profile.name)
        print("Relative path: " .. profile.relative)
        print("Full path: " .. profile.path)
        print("Detected format: " .. profile.format)

        local file, err = io.open(profile.path, "rb")
        if file ~= nil then
            local size = file:seek("end", 0)
            file:close()
            print("File size: " .. tostring(size or "unavailable") .. " bytes")
            print("Read test: opened successfully")
        else
            print("Read test: could not open file")
            print("Reason: " .. tostring(err))
        end

        print("")
        print("Browser only. The profile was NOT loaded or applied.")
    end)
end

local function make_profile_item(profile)
    return {
        name = profile.relative,
        help = "Select to inspect this file. No profile is applied.",
        select = function(this)
            show_profile(profile)
        end
    }
end

local function fill_format_submenu(target, format)
    for key in pairs(target) do target[key] = nil end

    local count = 0
    for _, profile in ipairs(profiles) do
        if profile.format == format then
            count = count + 1
            target[#target + 1] = make_profile_item(profile)
        end
    end

    if count == 0 then
        target[1] = {
            name = "No " .. format .. " files found",
            help = "See Show full scan report for folder diagnostics."
        }
    end

    return count
end

local pf2_submenu = {}
local pf3_submenu = {}
local pf2_menu_item = {
    name = "PF2 Profiles (0)",
    help = "Browse PF2 profiles. Selection only shows file details.",
    submenu = pf2_submenu
}
local pf3_menu_item = {
    name = "PF3 Profiles (0)",
    help = "Browse PF3 profiles. Selection only shows file details.",
    submenu = pf3_submenu
}

local function rebuild_profile_menus()
    local pf2_count = fill_format_submenu(pf2_submenu, "PF2")
    local pf3_count = fill_format_submenu(pf3_submenu, "PF3")
    pf2_menu_item.name = "PF2 Profiles (" .. tostring(pf2_count) .. ")"
    pf3_menu_item.name = "PF3 Profiles (" .. tostring(pf3_count) .. ")"
end

scan_profiles()
rebuild_profile_menus()

local menu_items = {
    {
        name = "Show full scan report",
        help = "Show how the SD-card root was resolved and what was detected.",
        select = function(this) show_report() end
    },
    {
        name = "Refresh profile list",
        help = "Rescan the SD-card PFProfiles folder.",
        select = function(this)
            scan_profiles()
            rebuild_profile_menus()
            show_report()
        end
    },
    pf2_menu_item,
    pf3_menu_item,
    {
        name = "Browser only - no importing",
        help = "This version does not register or apply Picture Styles."
    }
}

local recipe_lab_menu = menu.new {
    parent = "Scripts",
    name = "Recipe Lab",
    help = "Read-only PF2/PF3 browser. Resolves PFProfiles from the SD-card root.",
    submenu = menu_items
}
