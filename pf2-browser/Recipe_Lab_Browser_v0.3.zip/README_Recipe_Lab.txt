RECIPE LAB BROWSER - MAGIC LANTERN / CANON EOS 700D
Version 0.3 - READ-ONLY PF2/PF3 BROWSER

WHAT THIS DOES
- Locates the SD-card root by opening the known ML/SCRIPTS directory and
  following its parent objects up to the card root.
- Searches the card-root directory list for PFProfiles (case-insensitive).
- Scans PFProfiles and subfolders for .PF2 and .PF3 files.
- Shows separate PF2 and PF3 lists inside a Magic Lantern menu.
- Lets you inspect a selected file's path, format, and file size.
- Includes Refresh profile list and an expanded scan report.
- Does not import, register, or apply any Picture Style.

WHY V0.3 CHANGED THE PATH METHOD
In v0.2, dryos.directory("PFProfiles") reported exists=false on the camera,
even though the folder is present at the card root. v0.3 no longer opens that
relative path directly. Instead, it uses the same directory-object navigation
shown in the bundled ML/scripts/editor.lua:
  dryos.directory("ML/SCRIPTS") -> .parent (ML) -> .parent (card root)
It then finds the PFProfiles child object returned by card_root:children().
This avoids assuming how a relative root path is resolved by dryos.directory().

SD CARD LAYOUT
  /ML/scripts/recipe_lab.lua
  /PFProfiles/Fuji Pro 160C.pf2
  /PFProfiles/Polaroid_Polachrome_sixaxis.pf3

Subfolders are supported, for example:
  /PFProfiles/Kodak/Portra400.pf2
  /PFProfiles/Fujifilm/Pro160C.pf2

INSTALLATION
1. Keep a backup of the SD card.
2. Extract this ZIP to the SD-card root, allowing it to place the file at:
     /ML/SCRIPTS/recipe_lab.lua
3. Leave your existing root-level /PFProfiles folder and files untouched.
4. Safely eject the card, insert it into the EOS 700D, and boot Magic Lantern.
5. Run recipe_lab.lua from the Scripts menu.
6. Open Recipe Lab -> Show full scan report.
7. Use Refresh profile list after adding or removing recipes.

REPORT DETAILS
The report shows:
- Which ML/SCRIPTS anchor was opened.
- The resolved script-folder and card-root paths.
- The directory names seen at the card root.
- The discovered PFProfiles path.
- Profile counts and any scan warnings.

If PFProfiles is still not found, please send the complete report. The
"Directories at card root" section will show exactly what the directory API
is exposing to the script.

SAFETY / LIMITATIONS
This is a read-only browser prototype. It does not change camera settings,
register styles, or write to PF2/PF3 files. It uses directory-object APIs
already exercised by the supplied Magic Lantern editor.lua, but still needs
testing on the physical camera. It has not been tested on the physical 700D.
