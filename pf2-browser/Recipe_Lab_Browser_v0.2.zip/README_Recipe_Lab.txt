RECIPE LAB BROWSER - MAGIC LANTERN / CANON EOS 700D
Version 0.2 - READ-ONLY PROTOTYPE

WHAT THIS DOES
- Scans the SD-card root folder PFProfiles for .PF2 and .PF3 files.
- Finds files in subfolders up to four directory levels below PFProfiles.
- Shows separate PF2 and PF3 lists inside a Magic Lantern menu.
- Lets you inspect a selected file's path, format, and file size.
- Does not import, register, or apply any Picture Style.
- Does not write to profile files or camera settings.

IMPORTANT FIX IN V0.2
The first version used a trailing slash in dryos.directory("PFProfiles/")
 and treated dir:files() entries as full paths. The bundled editor.lua uses
 dryos.directory("ML/SCRIPTS") without a trailing slash, and its file dialog
 treats :files() entries as filenames. Version 0.2 follows that convention:
 it opens dryos.directory("PFProfiles") and combines dir.path with each name.

SD CARD LAYOUT
The script expects this layout:

    /ML/SCRIPTS/recipe_lab.lua
    /PFProfiles/Fuji Pro 160C.pf2
    /PFProfiles/Polaroid_Polachrome_sixaxis.pf3

You can also organise files in subfolders, for example:

    /PFProfiles/Kodak/Portra400.pf2
    /PFProfiles/Fujifilm/Pro160C.pf2

INSTALLATION
1. Back up the SD card.
2. Extract the ZIP to the SD-card root, allowing it to place the script at:
       /ML/SCRIPTS/recipe_lab.lua
3. Leave your profiles in the existing root-level /PFProfiles/ folder.
4. Safely eject the card and put it in the EOS 700D.
5. Start Magic Lantern and run recipe_lab.lua from Scripts.
6. Open the Recipe Lab menu.
7. Select "Show full scan report" first. It now reports whether PFProfiles
   exists, the resolved path, number of root files/subfolders, detected
   profiles, and any directory API errors.

USAGE
- PF2 Profiles and PF3 Profiles show the detected recipes.
- Selecting a profile only opens it read-only to check file size.
- If files are added or removed, restart/re-run the script to rescan.

SAFETY
This is still a browser-only prototype. It does not attempt to register or
apply Picture Styles, and it does not modify camera settings or profile files.
It has not yet been tested on the physical camera. Keep a backup of the card.
