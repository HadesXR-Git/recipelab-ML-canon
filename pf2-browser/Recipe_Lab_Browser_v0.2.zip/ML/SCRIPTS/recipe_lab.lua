-- Recipe Lab Browser for Magic Lantern (Canon EOS 700D / Nightly 2018Jul03)
-- Version: 0.2 - READ-ONLY PROFILE BROWSER
--
-- Scans the SD-card root folder PFProfiles for .PF2 and .PF3 files.
-- This version DOES NOT import, register, or apply Picture Styles.
--
-- Install as: ML/SCRIPTS/recipe_lab.lua
-- Profiles:   PFProfiles/<your profile files>

local PROFILE_ROOT = "PFProfiles" -- IMPORTANT: dryos.directory paths use no trailing slash.
local MAX_DEPTH = 4
local MAX_PROFILES = 250

local profiles = {}
local scan_warnings = {}
local scan_truncated = false
local root_info = {
    requested = PROFILE_ROOT,
    exists = false,
    resolved_path = "(not opened)",
    file_count = 0,
    directory_count = 0
}

local function basename(path)
    local clean = tostring(path or ""):gsub("/+$", "")
    return string.match(clean, "([^/]+)$") or clean
end

local function add_trailing_slash(path)
    path = tostring(path or "")
    if path ~= "" and string.sub(path, -1) ~= "/" then
        path = path .. "/"
    end
    return path
end

local function join_file_path(dir_path, file_name)
    file_name = tostring(file_name or "")
    -- Be tolerant in case a future API variant returns a full path from :files().
    if string.sub(file_name, 1, 1) == "/" or string.match(file_name, "^[A-Za-z]:/") then
        return file_name
    end
    return add_trailing_slash(dir_path) .. file_name
end

local function profile_format(file_name)
    local extension = string.match(basename(file_name), "%.([^%.]+)$")
    if extension == nil then return nil end

    extension = string.lower(extension)
    if extension == "pf2" then return "PF2" end
    if extension == "pf3" then return "PF3" end
    return nil
end

local function add_warning(message)
    if #scan_warnings < 30 then
        scan_warnings[#scan_warnings + 1] = tostring(message)
    end
end

local function add_profile(full_path, relative_path, file_name, format)
    local key = string.lower(full_path)
    for _, existing in ipairs(profiles) do
        if existing.key == key then return end
    end

    profiles[#profiles + 1] = {
        path = full_path,
        relative = relative_path,
        name = basename(file_name),
        format = format,
        key = key
    }
end

local function walk_directory(requested_path, depth, relative_dir)
    if #profiles >= MAX_PROFILES then
        scan_truncated = true
        return
    end

    -- Directory objects returned by :children() may expose paths with a
    -- trailing slash. Strip it before passing the path back to dryos.directory.
    local lookup_path = tostring(requested_path or ""):gsub("/+$", "")
    local dir_ok, dir_or_error = pcall(function()
        return dryos.directory(lookup_path)
    end)

    if not dir_ok then
        add_warning("dryos.directory error for '" .. lookup_path .. "': " .. tostring(dir_or_error))
        return
    end

    local dir = dir_or_error
    if dir == nil then
        add_warning("dryos.directory returned nil for '" .. lookup_path .. "'")
        return
    end

    if dir.exists ~= true then
        add_warning("Folder does not exist or is inaccessible: '" .. lookup_path .. "' (exists=" .. tostring(dir.exists) .. ")")
        return
    end

    local resolved_path = dir.path or requested_path
    local full_dir_path = add_trailing_slash(resolved_path)

    if depth == 0 then
        root_info.exists = true
        root_info.resolved_path = tostring(resolved_path)
    end

    local files_ok, files_or_error = pcall(function()
        return dir:files()
    end)

    if not files_ok then
        add_warning("dir:files() failed for '" .. tostring(resolved_path) .. "': " .. tostring(files_or_error))
    elseif type(files_or_error) ~= "table" then
        add_warning("dir:files() did not return a table for '" .. tostring(resolved_path) .. "' (got " .. type(files_or_error) .. ")")
    else
        if depth == 0 then root_info.file_count = #files_or_error end

        for _, file_entry in ipairs(files_or_error) do
            local file_name = tostring(file_entry)
            local format = profile_format(file_name)
            if format ~= nil then
                local full_path = join_file_path(full_dir_path, file_name)
                local relative = relative_dir .. basename(file_name)
                add_profile(full_path, relative, file_name, format)
                if #profiles >= MAX_PROFILES then
                    scan_truncated = true
                    break
                end
            end
        end
    end

    if depth < MAX_DEPTH and #profiles < MAX_PROFILES then
        local children_ok, children_or_error = pcall(function()
            return dir:children()
        end)

        if not children_ok then
            add_warning("dir:children() failed for '" .. tostring(resolved_path) .. "': " .. tostring(children_or_error))
        elseif type(children_or_error) ~= "table" then
            add_warning("dir:children() did not return a table for '" .. tostring(resolved_path) .. "' (got " .. type(children_or_error) .. ")")
        else
            if depth == 0 then root_info.directory_count = #children_or_error end
            table.sort(children_or_error, function(a, b)
                return tostring(a.path or "") < tostring(b.path or "")
            end)

            for _, child in ipairs(children_or_error) do
                if child ~= nil and child.path ~= nil then
                    local child_path = tostring(child.path)
                    local child_name = basename(child_path)
                    walk_directory(child_path, depth + 1, relative_dir .. child_name .. "/")
                else
                    add_warning("Encountered a subdirectory entry without a path under '" .. tostring(resolved_path) .. "'")
                end

                if #profiles >= MAX_PROFILES then
                    scan_truncated = true
                    break
                end
            end
        end
    end
end

local function scan_profiles()
    profiles = {}
    scan_warnings = {}
    scan_truncated = false
    root_info = {
        requested = PROFILE_ROOT,
        exists = false,
        resolved_path = "(not opened)",
        file_count = 0,
        directory_count = 0
    }

    -- The bundled editor.lua calls dryos.directory("ML/SCRIPTS"), without
    -- a leading slash or trailing slash. Follow that exact convention here.
    walk_directory(PROFILE_ROOT, 0, "")

    table.sort(profiles, function(a, b)
        local a_lower = string.lower(a.relative)
        local b_lower = string.lower(b.relative)
        if a_lower == b_lower then return a.relative < b.relative end
        return a_lower < b_lower
    end)
end

local function run_console(title, callback)
    task.create(function()
        menu.close()
        console.show()
        console.clear()

        print("RECIPE LAB - READ ONLY")
        print(title)
        print("--------------------------------")

        local ok, err = pcall(callback)
        if not ok then
            print("Script error: " .. tostring(err))
        end

        print("")
        print("No camera Picture Style settings were changed.")
        print("Press any key to return.")
        key.wait()
        console.hide()
    end)
end

local function show_report()
    run_console("SD-card scan report", function()
        local pf2_count, pf3_count = 0, 0
        for _, profile in ipairs(profiles) do
            if profile.format == "PF2" then pf2_count = pf2_count + 1 end
            if profile.format == "PF3" then pf3_count = pf3_count + 1 end
        end

        print("Requested folder: " .. root_info.requested)
        print("Folder exists: " .. tostring(root_info.exists))
        print("Resolved path: " .. tostring(root_info.resolved_path))
        print("Root files listed: " .. tostring(root_info.file_count))
        print("Root subfolders listed: " .. tostring(root_info.directory_count))
        print("")
        print("PF2 files found: " .. tostring(pf2_count))
        print("PF3 files found: " .. tostring(pf3_count))
        print("Total profiles: " .. tostring(#profiles))

        if #profiles > 0 then
            print("")
            print("Detected profiles:")
            for index, profile in ipairs(profiles) do
                print(string.format("%03d [%s] %s", index, profile.format, profile.relative))
            end
        end

        if scan_truncated then
            print("")
            print("Listing stopped at safety limit: " .. tostring(MAX_PROFILES))
        end

        if #scan_warnings > 0 then
            print("")
            print("Scan diagnostics:")
            for _, warning in ipairs(scan_warnings) do
                print("- " .. warning)
            end
        end

        if #profiles == 0 and #scan_warnings == 0 then
            print("")
            print("Folder opened, but no PF2/PF3 files were returned.")
            print("Check that the files are directly inside PFProfiles or its subfolders.")
        end
    end)
end

local function show_profile(profile)
    run_console("Profile details", function()
        print("Name: " .. profile.name)
        print("Relative path: " .. profile.relative)
        print("Full path: " .. profile.path)
        print("Detected format: " .. profile.format)

        local file, err = io.open(profile.path, "rb")
        if file ~= nil then
            local size = file:seek("end", 0)
            file:close()
            print("File size: " .. tostring(size or "unavailable") .. " bytes")
            print("Read test: opened successfully")
        else
            print("Read test: could not open file")
            print("Reason: " .. tostring(err))
        end

        print("")
        print("Browser only. The profile was NOT loaded or applied.")
    end)
end

local function make_profile_item(profile)
    return {
        name = profile.relative,
        help = "Select to inspect this file. No profile is applied.",
        select = function(this)
            show_profile(profile)
        end
    }
end

local function make_format_submenu(format, label)
    local items = {}
    for _, profile in ipairs(profiles) do
        if profile.format == format then
            items[#items + 1] = make_profile_item(profile)
        end
    end

    local count = #items
    if count == 0 then
        items[1] = {
            name = "No " .. format .. " files found",
            help = "See Show full scan report for folder diagnostics."
        }
    end

    return {
        name = label .. " (" .. tostring(count) .. ")",
        help = "Browse " .. format .. " profiles. Selection only shows file details.",
        submenu = items
    }
end

scan_profiles()

local menu_items = {
    {
        name = "Show full scan report",
        help = "Show resolved folder path, file counts, and scan diagnostics.",
        select = function(this) show_report() end
    },
    make_format_submenu("PF2", "PF2 Profiles"),
    make_format_submenu("PF3", "PF3 Profiles"),
    {
        name = "Browser only - no importing",
        help = "This version does not register or apply Picture Styles."
    }
}

local recipe_lab_menu = menu.new {
    parent = "Scripts",
    name = "Recipe Lab",
    help = "Read-only PF2/PF3 browser for the SD-card root PFProfiles folder.",
    submenu = menu_items
}
