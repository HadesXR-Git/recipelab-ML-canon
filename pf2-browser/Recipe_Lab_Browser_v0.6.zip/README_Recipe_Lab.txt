RECIPE LAB BROWSER - MAGIC LANTERN / CANON EOS 700D
Version 0.6 - READ-ONLY PF2/PF3 BROWSER (ROOT-ONLY SCAN)

WHY V0.6
Version 0.5 recursively scanned PFProfiles and all its subdirectories (up to
four levels). That can inflate the displayed total when the same collection is
represented in nested folders or when subfolders contain additional copies.
Your stated target is the 154 profiles placed directly in the root-level
/PFProfiles folder, so v0.6 deliberately scans only that one directory.

WHAT IT DOES
- Finds /PFProfiles using the working FAT 8.3 alias detection (PFPROF~1, etc.).
- Reads only files directly inside /PFProfiles.
- Detects .PF2 and .PF3 extensions case-insensitively.
- Does not recurse into subfolders.
- Counts subfolders for diagnostics and reports how many were skipped.
- Keeps paginated menus of 35 profiles per page.
- Retains a 250-profile safety cap.
- Selecting a profile only displays its path, format, and file size.

INSTALLATION
1. Back up the SD card.
2. Extract this ZIP at the SD-card root, replacing:
     /ML/SCRIPTS/recipe_lab.lua
3. Keep the profile files directly in:
     /PFProfiles/
4. Run recipe_lab.lua from Magic Lantern's Scripts menu.
5. Open Recipe Lab -> PF2 Profiles or PF3 Profiles.
6. Open Show full scan report and check:
     - Direct entries in PFProfiles
     - Subfolders not scanned
     - PF2 files found / PF3 files found / Total profiles

EXPECTED RESULT
If the 154 expected profiles are all directly in /PFProfiles, Total profiles
should be 154 (or the actual number of .PF2/.PF3 files in that folder).
If the total is still inflated, send the full scan report; v0.6 no longer walks
subdirectories, so the source of the extra entries will be easier to isolate.

SAFETY
This is a read-only browser. It does not register, import, or apply Picture
Styles and does not modify camera Picture Style settings.

TEST STATUS
PFProfiles discovery and short-alias handling were confirmed on the user's
700D with v0.4. The v0.6 root-only scan and unchanged pagination require a
fresh camera test.
