-- Recipe Lab Browser for Magic Lantern (Canon EOS 700D / Nightly 2018Jul03)
-- Version: 0.6 - READ-ONLY PF2/PF3 BROWSER (ROOT-ONLY SCAN)
--
-- Scans only files directly inside the root-level PFProfiles folder.
-- Subfolders are counted for diagnostics but deliberately not traversed.
--
-- Important v0.3 change:
--   Do NOT try dryos.directory("PFProfiles") directly. Instead, open the
--   known-good ML/SCRIPTS directory, walk up via .parent twice to the card
--   root, then find PFProfiles among the root directory's :children().
--   This follows the same Directory objects used by the bundled editor.lua.
--
-- Install as: ML/SCRIPTS/recipe_lab.lua
-- Profiles:   PFProfiles/<profiles and optional subfolders>
--
-- This script is READ-ONLY. It does not register or apply Picture Styles.

local PROFILE_FOLDER_NAME = "PFProfiles"
local PROFILE_FOLDER_SHORT_ALIAS_PREFIX = "PFPROF~"
local SCRIPT_ANCHOR_CANDIDATES = { "ML/SCRIPTS", "ML/scripts" }
-- The expected library is flat (files directly in PFProfiles). A conservative
-- cap is retained; menu pagination keeps the visible menu manageable.
local MAX_PROFILES = 250
local MENU_PAGE_SIZE = 35
local MAX_REPORT_PROFILES = 60
local MAX_ROOT_NAMES_IN_REPORT = 40

local profiles = {}
local profile_keys = {}
local scan_warnings = {}
local scan_truncated = false
local root_info = {}
local card_root_dir = nil
local profile_root_dir = nil

local function normalize_path(path)
    return tostring(path or ""):gsub("\\", "/")
end

local function basename(path)
    local clean = normalize_path(path):gsub("/+$", "")
    return string.match(clean, "([^/]+)$") or clean
end

local function add_trailing_slash(path)
    path = normalize_path(path)
    if path ~= "" and string.sub(path, -1) ~= "/" then
        path = path .. "/"
    end
    return path
end

local function join_path(dir_path, file_name)
    local name = normalize_path(file_name)
    if string.sub(name, 1, 1) == "/" or string.match(name, "^[A-Za-z]:/") then
        return name
    end
    return add_trailing_slash(dir_path) .. name
end

local function profile_format(file_name)
    local extension = string.match(basename(file_name), "%.([^%.]+)$")
    if extension == nil then return nil end

    extension = string.lower(extension)
    if extension == "pf2" then return "PF2" end
    if extension == "pf3" then return "PF3" end
    return nil
end

-- FAT 8.3 short-name fallback. The screenshot from the EOS 700D shows
-- PFPROF~1 in the root listing for the long folder name PFProfiles.
local function is_profile_folder_name(entry_name)
    local upper = string.upper(tostring(entry_name or ""))
    if upper == string.upper(PROFILE_FOLDER_NAME) then
        return true, "long name"
    end
    if string.match(upper, "^PFPROF~%d+$") then
        return true, "8.3 short-name alias"
    end
    return false, nil
end

local function add_warning(message)
    if #scan_warnings < 40 then
        scan_warnings[#scan_warnings + 1] = tostring(message)
    end
end

local function safe_directory(path)
    local ok, result = pcall(function()
        return dryos.directory(path)
    end)
    if not ok then
        return nil, "dryos.directory(" .. tostring(path) .. ") raised: " .. tostring(result)
    end
    if result == nil then
        return nil, "dryos.directory(" .. tostring(path) .. ") returned nil"
    end
    if result.exists ~= true then
        return nil, "Directory object for " .. tostring(path) .. " reports exists=" .. tostring(result.exists)
    end
    return result, nil
end

local function safe_children(dir, label)
    local ok, result = pcall(function()
        return dir:children()
    end)
    if not ok then
        add_warning("children() failed for " .. tostring(label) .. ": " .. tostring(result))
        return nil
    end
    if type(result) ~= "table" then
        add_warning("children() returned " .. type(result) .. " for " .. tostring(label))
        return nil
    end
    return result
end

local function safe_files(dir, label)
    local ok, result = pcall(function()
        return dir:files()
    end)
    if not ok then
        add_warning("files() failed for " .. tostring(label) .. ": " .. tostring(result))
        return nil
    end
    if type(result) ~= "table" then
        add_warning("files() returned " .. type(result) .. " for " .. tostring(label))
        return nil
    end
    return result
end

local function add_profile(full_path, relative_path, file_name, format)
    local key = string.lower(normalize_path(full_path))
    if profile_keys[key] then return end
    profile_keys[key] = true

    -- Store only the fields needed by the browser. Avoid retaining duplicate
    -- path/name strings for every profile on the camera's limited Lua heap.
    profiles[#profiles + 1] = {
        path = full_path,
        relative = relative_path,
        format = format
    }
end

-- Resolve the card root using the parent chain of a known-good ML folder.
-- editor.lua in this exact build initializes its file dialog with
-- dryos.directory("ML/SCRIPTS") and navigates folders through .parent.
local function resolve_profile_folder()
    local anchor = nil
    local anchor_path = nil
    local anchor_errors = {}

    for _, candidate in ipairs(SCRIPT_ANCHOR_CANDIDATES) do
        local result, err = safe_directory(candidate)
        if result ~= nil then
            anchor = result
            anchor_path = candidate
            break
        end
        anchor_errors[#anchor_errors + 1] = err
    end

    if anchor == nil then
        add_warning("Could not open the known ML/SCRIPTS anchor. " .. table.concat(anchor_errors, " | "))
        return nil
    end

    root_info.anchor_path = anchor_path
    root_info.anchor_resolved_path = tostring(anchor.path or "(no path property)")

    local ml_dir = anchor.parent
    if ml_dir == nil then
        add_warning("The ML/SCRIPTS directory has no parent object; cannot derive card root.")
        return nil
    end

    local root_dir = ml_dir.parent
    if root_dir == nil then
        add_warning("The ML directory has no parent object; cannot derive card root.")
        return nil
    end

    if root_dir.exists ~= true then
        add_warning("Derived card-root object reports exists=" .. tostring(root_dir.exists))
        return nil
    end

    card_root_dir = root_dir
    root_info.card_root_path = tostring(root_dir.path or "(no path property)")

    local root_children = safe_children(root_dir, "SD-card root")
    if root_children == nil then return nil end

    root_info.root_directory_count = #root_children
    root_info.root_directory_names = {}
    table.sort(root_children, function(a, b)
        return string.lower(basename(a and a.path or "")) < string.lower(basename(b and b.path or ""))
    end)

    for _, child in ipairs(root_children) do
        if child ~= nil and child.path ~= nil then
            local child_name = basename(child.path)
            if #root_info.root_directory_names < MAX_ROOT_NAMES_IN_REPORT then
                root_info.root_directory_names[#root_info.root_directory_names + 1] = child_name
            end
            local is_match, match_type = is_profile_folder_name(child_name)
            if is_match then
                profile_root_dir = child
                root_info.profile_folder_entry_name = child_name
                root_info.profile_folder_match_type = match_type
            end
        else
            add_warning("A card-root child directory had no path property.")
        end
    end

    if profile_root_dir == nil then
        add_warning("Could not find '" .. PROFILE_FOLDER_NAME .. "' among the SD-card root directories.")
        return nil
    end

    root_info.profile_folder_path = tostring(profile_root_dir.path or "(no path property)")
    if profile_root_dir.exists ~= true then
        add_warning("Found PFProfiles entry, but it reports exists=" .. tostring(profile_root_dir.exists))
        return nil
    end

    return profile_root_dir
end

local function scan_profile_root(dir)
    if dir == nil or dir.exists ~= true then
        add_warning("PFProfiles directory is not available for scanning.")
        return
    end

    local dir_path = tostring(dir.path or "")
    if dir_path == "" then
        add_warning("PFProfiles directory has no path property.")
        return
    end

    -- The user's library is stored directly in /PFProfiles. Earlier recursive
    -- scanning included files from nested folders and inflated the count.
    -- Keep this version strictly flat: one directory, one files() call.
    local file_entries = safe_files(dir, dir_path)
    if file_entries == nil then return end

    root_info.profile_file_count = #file_entries

    for _, file_entry in ipairs(file_entries) do
        local file_name = tostring(file_entry)
        local format = profile_format(file_name)
        if format ~= nil then
            if #profiles >= MAX_PROFILES then
                scan_truncated = true
                add_warning("Profile safety cap reached; remaining root-level files were not added.")
                break
            end

            local full_path = join_path(dir_path, file_name)
            local relative = basename(file_name)
            add_profile(full_path, relative, file_name, format)
        end
    end

    -- Count subfolders, but do not scan them. This makes it obvious if there
    -- are nested directories that the flat scanner intentionally skipped.
    local children = safe_children(dir, dir_path)
    root_info.profile_subdirectory_count = children and #children or 0
end

local function scan_profiles()
    profiles = {}
    profile_keys = {}
    scan_warnings = {}
    scan_truncated = false
    card_root_dir = nil
    profile_root_dir = nil
    root_info = {
        anchor_path = "(not opened)",
        anchor_resolved_path = "(not opened)",
        card_root_path = "(not resolved)",
        root_directory_count = 0,
        root_directory_names = {},
        profile_folder_path = "(not found)",
        profile_folder_entry_name = "(not found)",
        profile_folder_match_type = "(not matched)",
        profile_file_count = 0,
        profile_subdirectory_count = 0
    }

    local target = resolve_profile_folder()
    if target ~= nil then
        scan_profile_root(target)
    end

    table.sort(profiles, function(a, b)
        local a_lower = string.lower(a.relative)
        local b_lower = string.lower(b.relative)
        if a_lower == b_lower then return a.relative < b.relative end
        return a_lower < b_lower
    end)
end

local function run_console(title, callback)
    task.create(function()
        menu.close()
        console.show()
        console.clear()

        print("RECIPE LAB - READ ONLY")
        print(title)
        print("--------------------------------")

        local ok, err = pcall(callback)
        if not ok then
            print("Script error: " .. tostring(err))
        end

        print("")
        print("No camera Picture Style settings were changed.")
        print("Press any key to return.")
        key.wait()
        console.hide()
    end)
end

local function show_report()
    run_console("SD-card scan report", function()
        local pf2_count, pf3_count = 0, 0
        for _, profile in ipairs(profiles) do
            if profile.format == "PF2" then pf2_count = pf2_count + 1 end
            if profile.format == "PF3" then pf3_count = pf3_count + 1 end
        end

        print("Anchor opened: " .. tostring(root_info.anchor_path))
        print("Anchor path: " .. tostring(root_info.anchor_resolved_path))
        print("Card root path: " .. tostring(root_info.card_root_path))
        print("Root directories: " .. tostring(root_info.root_directory_count))
        print("PFProfiles path: " .. tostring(root_info.profile_folder_path))
        print("Root entry matched: " .. tostring(root_info.profile_folder_entry_name))
        print("Match method: " .. tostring(root_info.profile_folder_match_type))
        print("Direct entries in PFProfiles: " .. tostring(root_info.profile_file_count))
        print("Subfolders not scanned: " .. tostring(root_info.profile_subdirectory_count))
        print("Scan mode: root files only (no recursion)")
        print("")
        print("PF2 files found: " .. tostring(pf2_count))
        print("PF3 files found: " .. tostring(pf3_count))
        print("Total profiles: " .. tostring(#profiles))

        if #root_info.root_directory_names > 0 then
            print("")
            print("Directories at card root:")
            for _, name in ipairs(root_info.root_directory_names) do
                print("- " .. tostring(name))
            end
            if root_info.root_directory_count > #root_info.root_directory_names then
                print("(list limited to " .. tostring(MAX_ROOT_NAMES_IN_REPORT) .. ")")
            end
        end

        if #profiles > 0 then
            print("")
            print("Detected profiles (first " .. tostring(math.min(#profiles, MAX_REPORT_PROFILES)) .. "):")
            local report_count = math.min(#profiles, MAX_REPORT_PROFILES)
            for index = 1, report_count do
                local profile = profiles[index]
                print(string.format("%03d [%s] %s", index, profile.format, profile.relative))
            end
            if #profiles > report_count then
                print("... plus " .. tostring(#profiles - report_count) .. " more; browse the paginated PF2/PF3 menus.")
            end
        end

        if scan_truncated then
            print("")
            print("Scan reached the safety cap of " .. tostring(MAX_PROFILES) .. " profiles.")
            print("Additional profiles may exist and were not loaded into the browser.")
        end

        if #scan_warnings > 0 then
            print("")
            print("Scan diagnostics:")
            for _, warning in ipairs(scan_warnings) do
                print("- " .. warning)
            end
        end

        if #profiles == 0 and #scan_warnings == 0 then
            print("")
            print("PFProfiles was opened, but no PF2/PF3 files were found.")
        end
    end)
end

local function show_profile(profile)
    run_console("Profile details", function()
        print("Name: " .. basename(profile.relative))
        print("Relative path: " .. profile.relative)
        print("Full path: " .. profile.path)
        print("Detected format: " .. profile.format)

        local file, err = io.open(profile.path, "rb")
        if file ~= nil then
            local size = file:seek("end", 0)
            file:close()
            print("File size: " .. tostring(size or "unavailable") .. " bytes")
            print("Read test: opened successfully")
        else
            print("Read test: could not open file")
            print("Reason: " .. tostring(err))
        end

        print("")
        print("Browser only. The profile was NOT loaded or applied.")
    end)
end

local function make_profile_item(profile)
    return {
        name = profile.relative,
        help = "Select to inspect this file. No profile is applied.",
        select = function(this)
            show_profile(profile)
        end
    }
end

local function build_format_submenu(format)
    local format_profiles = {}
    for _, profile in ipairs(profiles) do
        if profile.format == format then
            format_profiles[#format_profiles + 1] = profile
        end
    end

    local count = #format_profiles
    local submenu = {}

    if count == 0 then
        submenu[1] = {
            name = "No " .. format .. " files found",
            help = "See Show full scan report for folder diagnostics."
        }
        return submenu, 0
    end

    -- menu.new converts submenu tables into native menu entries at creation.
    -- Build every page before calling menu.new; don't mutate this table later.
    if count <= MENU_PAGE_SIZE then
        for _, profile in ipairs(format_profiles) do
            submenu[#submenu + 1] = make_profile_item(profile)
        end
        return submenu, count
    end

    local total_pages = math.ceil(count / MENU_PAGE_SIZE)
    for page = 1, total_pages do
        local first_index = (page - 1) * MENU_PAGE_SIZE + 1
        local last_index = math.min(first_index + MENU_PAGE_SIZE - 1, count)
        local page_items = {}

        for index = first_index, last_index do
            page_items[#page_items + 1] = make_profile_item(format_profiles[index])
        end

        submenu[#submenu + 1] = {
            name = string.format("Page %02d (%d-%d)", page, first_index, last_index),
            help = string.format("Browse profiles %d through %d of %d.", first_index, last_index, count),
            submenu = page_items
        }
    end

    return submenu, count
end

local recipe_lab_menu = nil
local refresh_and_rebuild

local function create_recipe_lab_menu()
    local pf2_submenu, pf2_count = build_format_submenu("PF2")
    local pf3_submenu, pf3_count = build_format_submenu("PF3")

    local menu_items = {
        {
            name = "Show full scan report",
            help = "Show SD-card paths, file counts, and scan diagnostics.",
            select = function(this) show_report() end
        },
        {
            name = "Refresh profile list",
            help = "Rescan PFProfiles and rebuild the complete menu tree.",
            select = function(this) refresh_and_rebuild() end
        },
        {
            name = "PF2 Profiles (" .. tostring(pf2_count) .. ")",
            help = "Browse PF2 profiles. Large collections are divided into page submenus.",
            submenu = pf2_submenu
        },
        {
            name = "PF3 Profiles (" .. tostring(pf3_count) .. ")",
            help = "Browse PF3 profiles. Large collections are divided into page submenus.",
            submenu = pf3_submenu
        },
        {
            name = "Browser only - no importing",
            help = "This version does not register or apply Picture Styles."
        },
        {
            name = "Limits: 250 profiles / 35 per page",
            help = "The scanner reads only direct files in PFProfiles; cap is 250."
        }
    }

    return menu.new {
        parent = "Scripts",
        name = "Recipe Lab",
        help = "Read-only root-only PF2/PF3 browser with paginated submenus and PFProfiles FAT 8.3 alias support.",
        submenu = menu_items
    }
end

refresh_and_rebuild = function()
    task.create(function()
        menu.close()
        scan_profiles()

        if recipe_lab_menu ~= nil then
            local ok, err = pcall(function()
                recipe_lab_menu:remove()
            end)
            if not ok then
                add_warning("This build could not remove the old menu entry: " .. tostring(err))
                add_warning("The scan was refreshed, but restart the camera to rebuild the visible menu safely.")
                show_report()
                return
            end
            recipe_lab_menu = nil
        end

        recipe_lab_menu = create_recipe_lab_menu()
        show_report()
    end)
end

scan_profiles()
recipe_lab_menu = create_recipe_lab_menu()
