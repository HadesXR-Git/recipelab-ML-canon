RECIPE LAB BROWSER - MAGIC LANTERN / CANON EOS 700D
Version 0.5 - READ-ONLY PF2/PF3 BROWSER

WHAT CHANGED IN V0.5
- Increased the profile scan safety cap from 250 to 1000.
- Split large PF2 and PF3 collections into page submenus of 35 entries.
- Builds page submenus before menu.new. Magic Lantern converts Lua submenu
  tables into native menu entries when menu.new is called, so later mutations
  to those Lua tables are not relied on to update the camera menu.
- The scan report lists only the first 60 profile names. Browse the complete
  detected collection through the PF2/PF3 page submenus.
- Uses a lookup table for duplicate-path detection to avoid repeated linear scans.
- Stores only path, relative path, and format per profile to reduce Lua memory.
- Refresh rescans the card, removes the old Recipe Lab menu, and rebuilds it.

INSTALLATION
1. Back up the SD card.
2. Extract this ZIP at the SD-card root, replacing:
     /ML/SCRIPTS/recipe_lab.lua
3. Keep your profiles in the existing root-level /PFProfiles folder.
4. Run recipe_lab.lua from Magic Lantern's Scripts menu.
5. Open Recipe Lab -> PF2 Profiles or PF3 Profiles.
6. For larger libraries, open Page 01, Page 02, etc.

LIMITS
- The scanner can retain up to 1000 PF2/PF3 entries in one scan.
- Each page submenu displays at most 35 profiles.
- If the report says the 1000-profile cap was reached, additional profiles may
  exist but are not loaded.
- Subdirectory traversal remains limited to depth 4.

SAFETY
This is still a read-only browser. It does not register, import, or apply
Picture Styles. No camera Picture Style settings are modified.

TEST STATUS
The SD-card PFProfiles discovery and 8.3 alias handling were confirmed by the
user's camera test on v0.4. Version 0.5 pagination and expanded scan cap are
new and require camera testing.
