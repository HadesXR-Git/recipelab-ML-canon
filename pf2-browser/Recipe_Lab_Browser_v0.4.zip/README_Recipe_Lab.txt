RECIPE LAB BROWSER - MAGIC LANTERN / CANON EOS 700D
Version 0.4 - READ-ONLY PF2/PF3 BROWSER

WHAT CHANGED IN V0.4
The v0.3 report from the camera showed that the SD-card root directory listing
contains an entry named PFPROF~1, not PFProfiles. This is the FAT 8.3 short-name
alias for the long folder name PFProfiles.

v0.4 now accepts either:
  PFProfiles       (long name)
  PFPROF~1         (short name)
  PFPROF~2, etc.   (short-name collision variants)

It keeps the directory object returned by root:children() and scans that object.
It does not try to open PFPROF~1 as a separately constructed path.

INSTALLATION
1. Back up the SD card.
2. Extract this ZIP at the SD-card root, replacing:
     /ML/SCRIPTS/recipe_lab.lua
3. Do not rename your existing /PFProfiles folder.
4. Keep your PF2/PF3 files in that folder as before.
5. Run recipe_lab.lua from Magic Lantern's Scripts menu.
6. Open Recipe Lab -> Show full scan report.

EXPECTED REPORT
The root directory entry should now be detected as PFPROF~1, with match method
reported as "8.3 short-name alias". The PFProfiles path will be the path returned
by Magic Lantern for that directory object (it may itself contain PFPROF~1).

SAFETY / LIMITATIONS
This is still a read-only browser. It does not register, import, or apply any
Picture Style. PF2/PF3 loading is not implemented. Camera testing of v0.4 is
still required.
